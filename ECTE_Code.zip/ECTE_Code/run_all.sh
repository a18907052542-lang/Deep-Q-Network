#!/bin/bash
# End-to-end pipeline: train and evaluate every agent across the five
# cross-validation folds, then write tables and figures.

set -e
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

echo "======================================================================"
echo "  ECTE adaptive tutoring: end-to-end pipeline"
echo "======================================================================"

echo -e "\n[1/3] Training and evaluating agents across 5 folds and 5 seeds ..."
python scripts/run_experiment.py

echo -e "\n[2/3] Writing evaluation tables ..."
python scripts/generate_tables.py

echo -e "\n[3/3] Rendering figures ..."
python scripts/generate_figures.py

echo -e "\n======================================================================"
echo "  Done. Deliverables:"
echo "    outputs/tables/   evaluation tables (CSV + Markdown)"
echo "    outputs/figures/  figures (PNG at DPI 600)"
echo "    outputs/logs/     per-fold metrics"
echo "======================================================================"
