"""
Gym-like environment that wraps the fitted learner simulator and returns
transitions (s_t, a_t, r_t, s_{t+1}, valid mask_{t+1}, done, breakthrough).

Every step corresponds to one recommended activity. An episode covers one
learner in one course and ends when all target KPs reach k_mas or after
T_max steps.
"""

from collections import deque

import numpy as np

import config
from src.mask import decode_action, encode_action
from src.state import LearnerState
from src.reward import composite_reward


class TutoringEnvironment:
    """
    The simulator can be a DKTSimulator (training) or a CAKTSimulator
    (evaluation). Both expose reset() and step(a_index, preference).
    """

    def __init__(self, data, kg, action_mask, simulator, agent_bkt,
                 course_id="C1"):
        self.data = data
        self.kg = kg
        self.mask = action_mask
        self.sim = simulator
        self.agent_bkt = agent_bkt        # dict with guess, slip, transit
        self.course_id = course_id
        self.kp_pool = data.course_kp_pool[course_id]
        self.state = None
        self.t = 0
        self.recent_masteries = deque(maxlen=4)
        self.consecutive_errors_per_kp = {}
        self.log = []
        self.latent_correct = []          # simulator's ground truth

    def reset(self, learner_row):
        self.t = 0
        self.log.clear()
        self.latent_correct.clear()
        self.recent_masteries.clear()
        self.consecutive_errors_per_kp.clear()
        # Initial mastery from baseline; jitter per KP so the network sees
        # variability across learners
        k0 = np.clip(np.random.normal(
            float(learner_row["baseline_mastery"]), 0.05, size=config.N_KP),
            0.02, 0.99).astype(np.float32)
        p0 = np.zeros(11, dtype=np.float32)
        p0[:4] = 0.25
        p0[4:8] = 0.25
        p0[8:] = 1.0 / 3
        self.state = LearnerState(
            k0=k0, p0=p0,
            guess=self.agent_bkt["guess"],
            slip=self.agent_bkt["slip"],
            transit_table=self.agent_bkt["transit"],
            log_rt_mu=self.agent_bkt["log_rt_mu"],
            log_rt_sigma=self.agent_bkt["log_rt_sigma"],
            cog_weights=self.agent_bkt["omega"],
        )
        self.sim.reset()
        return self.state.to_vector(), self._current_mask()

    def _current_mask(self):
        return self.mask.valid_mask_np(self.state.k, course_kp_pool=self.kp_pool)

    def step(self, a_index):
        j, l, q = decode_action(a_index)
        # Simulator emits a response and a response time
        y, rt, latent_p = self.sim.step(a_index, self.state.p)
        # Track prerequisite satisfaction BEFORE the update, for R_path
        k_before = self.state.k.copy()

        # Update the three-component state
        delta = self.state.update_knowledge(j, l, q, y)

        media_index = {1: 1, 2: 2, 3: 0, 4: 0}[q]
        self.state.update_preference(l, q, hour_of_day=10, media_index=media_index)
        self.state.update_cognitive_load(a_index, rt, y)

        # Breakthrough b_t: mastery crosses k_mas after >= 2 recent errors
        b_t = 0
        recent = self.consecutive_errors_per_kp.get(j, 0)
        if y == 1 and self.state.k[j - 1] >= config.K_MAS \
                and k_before[j - 1] < config.K_MAS and recent >= 2:
            b_t = 1
        self.consecutive_errors_per_kp[j] = (recent + 1) if y == 0 else 0

        # Reward (Eq. 12)
        delta_vec = np.zeros(config.N_KP, dtype=np.float32)
        delta_vec[j - 1] = delta
        r_t, comp = composite_reward(
            delta_vec, j, k_before, self.state.c, self.kg)

        self.t += 1
        mastered_all = np.all(self.state.k[np.array(self.kp_pool) - 1]
                              >= config.K_MAS)
        done = bool(mastered_all or self.t >= config.T_MAX)

        next_mask = self._current_mask()
        info = {"y": y, "rt": rt, "latent_p": latent_p,
                "j": j, "l": l, "q": q,
                "R_know": comp["R_know"], "R_path": comp["R_path"],
                "R_cog": comp["R_cog"], "breakthrough": b_t}
        self.log.append(info)
        return self.state.to_vector(), r_t, done, next_mask, b_t, info
