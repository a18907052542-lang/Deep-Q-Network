"""
Networks for ID3QN and the value based baselines. All share the same
hidden sizes 256 - 128 - 64 with ReLU (Table S8).

Standard DQN                : 80 -> 256 -> 128 -> 64 -> 816
Dueling network             : shared 80 -> 256 -> 128, then two 64-unit
                              streams producing V (1) and A (816); the
                              masked aggregation of Eq. (8) happens in
                              agents/id3qn.py
Rainbow (distributional)    : same body plus 51 categorical atoms per
                              action, noisy final layer.
"""

import math

import torch
import torch.nn as nn
import torch.nn.functional as F

import config


class QNetwork(nn.Module):
    """Plain DQN network; output is Q(s, a) for every a."""

    def __init__(self):
        super().__init__()
        h1, h2, h3 = config.HIDDEN
        self.body = nn.Sequential(
            nn.Linear(config.STATE_DIM, h1),
            nn.ReLU(),
            nn.Linear(h1, h2),
            nn.ReLU(),
            nn.Linear(h2, h3),
            nn.ReLU(),
        )
        self.head = nn.Linear(h3, config.N_ACTIONS)

    def forward(self, s):
        return self.head(self.body(s))


class DuelingQNetwork(nn.Module):
    """Dueling network with shared body and two 64-unit streams (Eq. 8).

    Aggregation with mask is performed in the agent to keep this module
    interchangeable with the plain baselines.
    """

    def __init__(self):
        super().__init__()
        h1, h2, h3 = config.HIDDEN
        self.shared = nn.Sequential(
            nn.Linear(config.STATE_DIM, h1),
            nn.ReLU(),
            nn.Linear(h1, h2),
            nn.ReLU(),
        )
        self.value_stream = nn.Sequential(
            nn.Linear(h2, h3), nn.ReLU(), nn.Linear(h3, 1))
        self.advantage_stream = nn.Sequential(
            nn.Linear(h2, h3), nn.ReLU(), nn.Linear(h3, config.N_ACTIONS))

    def forward(self, s):
        z = self.shared(s)
        v = self.value_stream(z)                     # (B, 1)
        a = self.advantage_stream(z)                 # (B, |A|)
        return v, a


def aggregate_q(v, a, mask):
    """Eq. (8) with mask over valid actions.
    v: (B, 1); a: (B, |A|); mask: bool (B, |A|).
    Invalid actions receive -inf so they never enter the argmax."""
    mask_f = mask.float()
    # Mean advantage restricted to valid actions
    count = mask_f.sum(dim=1, keepdim=True).clamp(min=1.0)
    a_masked_sum = (a * mask_f).sum(dim=1, keepdim=True)
    a_mean = a_masked_sum / count
    q = v + a - a_mean
    q = q.masked_fill(~mask, float("-inf"))
    return q


# ------------------------------------------------------------------
# Rainbow: distributional dueling network with noisy last layer
# ------------------------------------------------------------------
class NoisyLinear(nn.Module):
    """Factorised Gaussian noise (Fortunato et al. 2018)."""

    def __init__(self, in_f, out_f, sigma_init=0.3):
        super().__init__()
        self.in_f = in_f
        self.out_f = out_f
        self.mu_w = nn.Parameter(torch.empty(out_f, in_f))
        self.sigma_w = nn.Parameter(torch.empty(out_f, in_f))
        self.register_buffer("eps_w", torch.zeros(out_f, in_f))
        self.mu_b = nn.Parameter(torch.empty(out_f))
        self.sigma_b = nn.Parameter(torch.empty(out_f))
        self.register_buffer("eps_b", torch.zeros(out_f))
        bound = 1.0 / math.sqrt(in_f)
        nn.init.uniform_(self.mu_w, -bound, bound)
        nn.init.uniform_(self.mu_b, -bound, bound)
        nn.init.constant_(self.sigma_w, sigma_init / math.sqrt(in_f))
        nn.init.constant_(self.sigma_b, sigma_init / math.sqrt(out_f))
        self.reset_noise()

    def _scale(self, size):
        x = torch.randn(size)
        return x.sign() * x.abs().sqrt()

    def reset_noise(self):
        eps_in = self._scale(self.in_f)
        eps_out = self._scale(self.out_f)
        self.eps_w.copy_(eps_out.ger(eps_in))
        self.eps_b.copy_(eps_out)

    def forward(self, x):
        if self.training:
            w = self.mu_w + self.sigma_w * self.eps_w
            b = self.mu_b + self.sigma_b * self.eps_b
        else:
            w, b = self.mu_w, self.mu_b
        return F.linear(x, w, b)


class RainbowNetwork(nn.Module):
    def __init__(self, n_atoms=51, v_min=-200.0, v_max=200.0):
        super().__init__()
        self.n_atoms = n_atoms
        self.v_min = v_min
        self.v_max = v_max
        h1, h2, h3 = config.HIDDEN
        self.shared = nn.Sequential(
            nn.Linear(config.STATE_DIM, h1), nn.ReLU(),
            nn.Linear(h1, h2), nn.ReLU())
        self.value_stream = nn.Sequential(
            nn.Linear(h2, h3), nn.ReLU(), NoisyLinear(h3, n_atoms))
        self.advantage_stream = nn.Sequential(
            nn.Linear(h2, h3), nn.ReLU(),
            NoisyLinear(h3, config.N_ACTIONS * n_atoms))
        self.register_buffer("support",
                             torch.linspace(v_min, v_max, n_atoms))

    def reset_noise(self):
        for m in self.modules():
            if isinstance(m, NoisyLinear):
                m.reset_noise()

    def forward(self, s):
        z = self.shared(s)
        v = self.value_stream(z).view(-1, 1, self.n_atoms)
        a = self.advantage_stream(z).view(-1, config.N_ACTIONS, self.n_atoms)
        a_mean = a.mean(dim=1, keepdim=True)
        logits = v + a - a_mean
        return F.softmax(logits, dim=-1)   # (B, |A|, n_atoms)
