"""
Three-component state s_t = [k_t; p_t; c_t]  (section 3.2).

    k_t : 68-dim knowledge mastery vector, updated by BKT (Eq. 1 and 2)
    p_t : 11-dim learning preference vector, updated by exponential
          smoothing (Eq. 3): 4 resource-type shares, 4 study-period
          shares, 3 media format shares (text, video, interactive)
    c_t : cognitive load scalar in [0, 1] (Eq. 4 and 5)

The state dimension is 80.
"""

from collections import deque

import numpy as np

import config


def bkt_posterior(k_prior, y, guess, slip):
    """
    Bayesian knowledge tracing posterior mastery (Eq. 1).
    k_prior in [0, 1], y in {0, 1}. Returns k_post in [0, 1].
    """
    if y == 1:
        num = k_prior * (1.0 - slip)
        den = num + (1.0 - k_prior) * guess
    else:
        num = k_prior * slip
        den = num + (1.0 - k_prior) * (1.0 - guess)
    return 0.0 if den <= 1e-9 else float(np.clip(num / den, 0.0, 1.0))


def bkt_transit(k_post, transit):
    """Eq. (2): k_{t+1,j} = k_hat + (1 - k_hat) * p^T_j(l, q)."""
    return float(np.clip(k_post + (1.0 - k_post) * transit, 0.0, 1.0))


class LearnerState:
    """Encapsulates s_t and its updates."""

    def __init__(self, k0, p0, guess, slip, transit_table,
                 log_rt_mu, log_rt_sigma, cog_weights):
        """
        k0             : (68,) initial mastery from pretest
        p0             : (11,) initial preference (uniform per block)
        guess, slip    : (68,) per KP BKT parameters
        transit_table  : (68, 3, 4) transition probability per (j, l, q)
        log_rt_mu, log_rt_sigma : dicts keyed by action index a, giving
                          mean and std of log response times
        cog_weights    : (5,) omega_0..omega_4 for Eq. (5)
        """
        self.k = np.asarray(k0, dtype=np.float32).copy()
        self.p = np.asarray(p0, dtype=np.float32).copy()
        self.c = 0.5
        self.guess = guess
        self.slip = slip
        self.transit = transit_table
        self.log_rt_mu = log_rt_mu
        self.log_rt_sigma = log_rt_sigma
        self.omega = cog_weights
        # Rolling windows of z and e over the last W activities
        self.z_hist = deque(maxlen=config.COG_WINDOW * 2)
        self.e_hist = deque(maxlen=config.COG_WINDOW * 2)

    # ---------------- Updates ----------------
    def update_knowledge(self, j, l, q, y):
        """Apply Eq. (1) followed by Eq. (2)."""
        k_prior = float(self.k[j - 1])
        k_post = bkt_posterior(k_prior, y, self.guess[j - 1], self.slip[j - 1])
        transit = float(self.transit[j - 1, l - 1, q - 1])
        self.k[j - 1] = bkt_transit(k_post, transit)
        return self.k[j - 1] - k_prior  # signed change of mastery

    def update_preference(self, l, q, hour_of_day, media_index):
        """
        Eq. (3): p_{t+1} = (1 - eta) * p_t + eta * o_t.
        Preference vector layout:
            [0..3]  resource type shares (video, interactive, reading, quiz)
            [4..7]  study period shares (morning, afternoon, evening, night)
            [8..10] media format shares (text, video, interactive)
        """
        o = np.zeros(11, dtype=np.float32)
        # resource block: index 0..3 corresponds to resource_type 1..4
        o[q - 1] = 1.0
        # study period block
        if 5 <= hour_of_day < 12:
            o[4] = 1.0
        elif 12 <= hour_of_day < 17:
            o[5] = 1.0
        elif 17 <= hour_of_day < 22:
            o[6] = 1.0
        else:
            o[7] = 1.0
        # media block
        o[8 + media_index] = 1.0
        eta = config.PREF_SMOOTHING_ETA
        self.p = (1 - eta) * self.p + eta * o

    def update_cognitive_load(self, a_index, response_time_s, y):
        """
        Eq. (4) rolling window and Eq. (5) sigmoid combination.
        """
        mu = self.log_rt_mu.get(a_index, 3.8)
        sigma = max(self.log_rt_sigma.get(a_index, 0.4), 0.1)
        z = (np.log(max(response_time_s, 1e-3)) - mu) / sigma
        e = 1.0 - y
        self.z_hist.append(z)
        self.e_hist.append(e)
        W = config.COG_WINDOW
        recent_z = np.mean(list(self.z_hist)[-W:])
        recent_e = np.mean(list(self.e_hist)[-W:])
        if len(self.z_hist) >= 2 * W:
            prev_z = np.mean(list(self.z_hist)[-2 * W:-W])
            prev_e = np.mean(list(self.e_hist)[-2 * W:-W])
        else:
            prev_z, prev_e = 0.0, 0.0
        w0, w1, w2, w3, w4 = self.omega
        lin = (w0 + w1 * recent_z + w2 * recent_e
               + w3 * (recent_z - prev_z) + w4 * (recent_e - prev_e))
        self.c = float(1.0 / (1.0 + np.exp(-lin)))

    # ---------------- Vector encoding ----------------
    def to_vector(self):
        v = np.concatenate([self.k, self.p, np.array([self.c])])
        return v.astype(np.float32)
