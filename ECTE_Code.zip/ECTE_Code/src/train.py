"""
Generic training loop shared by every learning agent, implementing the
main ID3QN training procedure (Algorithm 1).
"""

from collections import deque
import time

import numpy as np

import config


def run_episode(agent, env, learner_row, greedy=False):
    """Roll out one episode; return the sum of rewards and the episode log."""
    s, mask = env.reset(learner_row)
    total_r = 0.0
    trajectory = []
    for t in range(config.T_MAX):
        a = agent.greedy_act(s, mask) if greedy else agent.act(s, mask)
        s_next, r, done, mask_next, breakthrough, info = env.step(a)
        info["c_next"] = env.state.c
        trajectory.append(info)
        if not greedy:
            agent.push(s, a, r, s_next, done, mask_next, breakthrough)
            agent.update()
        s, mask = s_next, mask_next
        total_r += r
        if done:
            break
    return total_r, trajectory


def train_agent(agent, env, learners_train, learners_val,
                total_episodes, verbose_every=50):
    """Alg. 1: sample training learners, roll out, update."""
    validation_returns = []
    train_returns = deque(maxlen=100)
    t0 = time.time()
    for ep in range(1, total_episodes + 1):
        agent.anneal(ep, total_episodes)
        lrow = learners_train.sample(1).iloc[0]
        r, _ = run_episode(agent, env, lrow, greedy=False)
        train_returns.append(r)
        # Periodic validation
        if ep % max(1, total_episodes // 40) == 0 and len(learners_val) > 0:
            vals = []
            for _, lrow_v in learners_val.sample(min(5, len(learners_val))).iterrows():
                vr, _ = run_episode(agent, env, lrow_v, greedy=True)
                vals.append(vr)
            validation_returns.append(float(np.mean(vals)))
        if verbose_every and ep % verbose_every == 0:
            elapsed = time.time() - t0
            print(f"      ep {ep:5d}/{total_episodes}  "
                  f"train R (last100) = {np.mean(train_returns):7.2f}  "
                  f"eps = {getattr(agent, 'eps', 0):.3f}  "
                  f"elapsed = {elapsed:.1f}s")
    return validation_returns
