"""
Validity mask of Eq. (6):

    A_t = { (j, l, q) in A : (j, l, q) in B, k_{t,j} < k_mas,
            N_log(j, l, q) >= N_min }

The mask is applied inside both the double Q-learning target (Eq. 7) and
the dueling aggregation (Eq. 8), which is what distinguishes ID3QN from
D3QN+PER (section 3.3).
"""

import numpy as np
import torch

import config


def encode_action(j, l, q):
    """Index = 12*(j-1) + 4*(l-1) + q, in 1..816.  Return zero based 0..815."""
    return 12 * (j - 1) + 4 * (l - 1) + (q - 1)


def decode_action(a):
    """Reverse of encode_action; return (j, l, q), 1 based."""
    j = a // 12 + 1
    rem = a % 12
    l = rem // 4 + 1
    q = rem % 4 + 1
    return j, l, q


class ActionMask:
    """
    Precomputes a static base mask (support and offered combinations) and
    combines it dynamically with the mastery mask k_{t,j} < k_mas.
    """

    def __init__(self, data):
        self.n_actions = config.N_ACTIONS

        # 1. Offered combinations (set B)
        offered = np.zeros(self.n_actions, dtype=bool)
        for _, row in data.items.iterrows():
            a = encode_action(int(row["knowledge_point_id"]),
                              int(row["difficulty_level"]),
                              int(row["resource_type"]))
            offered[a] = True

        # 2. Log-support count N_log per (j, l, q)
        combo_counts = (
            data.interactions
            .groupby(["knowledge_point_id", "difficulty_level", "resource_type"])
            .size()
        )
        support = np.zeros(self.n_actions, dtype=int)
        for (j, l, q), n in combo_counts.items():
            support[encode_action(int(j), int(l), int(q))] = int(n)

        # 3. Static base mask
        self.base_mask = offered & (support >= config.N_MIN)
        self.base_mask_t = torch.from_numpy(self.base_mask.astype(np.uint8))
        self.support = support
        self.offered = offered

    def valid_mask_np(self, k_vec, course_kp_pool=None):
        """
        Numpy version. Returns a boolean vector of length n_actions.
        k_vec: length-68 mastery vector, indexed 0..67.
        course_kp_pool: optional set of KP ids (1 based) restricting the
        pool to a course.
        """
        mask = self.base_mask.copy()
        for j in range(1, config.N_KP + 1):
            if k_vec[j - 1] >= config.K_MAS:
                start = 12 * (j - 1)
                mask[start:start + 12] = False
        if course_kp_pool is not None:
            allowed = np.zeros_like(mask)
            for j in course_kp_pool:
                start = 12 * (j - 1)
                allowed[start:start + 12] = True
            mask &= allowed
        return mask

    def valid_mask_t(self, k_vec_t, course_kp_pool=None):
        """
        Torch version. k_vec_t is a 1D tensor of length 68 on any device.
        Returns a bool tensor of length n_actions on the same device.
        """
        device = k_vec_t.device
        mask = self.base_mask_t.to(device).bool().clone()
        mastered = k_vec_t >= config.K_MAS
        if mastered.any():
            for j in torch.nonzero(mastered, as_tuple=False).flatten().tolist():
                start = 12 * j
                mask[start:start + 12] = False
        if course_kp_pool is not None:
            allowed = torch.zeros_like(mask)
            for j in course_kp_pool:
                start = 12 * (j - 1)
                allowed[start:start + 12] = True
            mask &= allowed
        return mask
