"""
Evaluate a trained policy against the six metrics of Table 4 on the
test learners of a fold, using the AKT evaluation simulator.
"""

import numpy as np

import config
from src.metrics import compute_ra, compute_pvr, compute_clmr, compute_nlg
from src.train import run_episode


def evaluate_policy(agent, env, learners_test, kg, seed=0):
    """
    Return a dict with mean RA, NLG, PVR, ACR, CLMR over test learners.
    """
    np.random.seed(seed)
    ra_list, nlg_list, pvr_list, acr_list, clmr_list = [], [], [], [], []
    for _, lrow in learners_test.iterrows():
        pre = 100.0 * float(lrow["baseline_mastery"])
        acr, traj = run_episode(agent, env, lrow, greedy=True)
        # Latent state after the last step approximates posttest
        post = 100.0 * float(np.mean(env.state.k))
        k_before_by_step = []
        k_running = np.clip(
            np.random.normal(float(lrow["baseline_mastery"]), 0.05,
                             size=config.N_KP), 0.02, 0.99)
        for e in traj:
            k_before_by_step.append(k_running.copy())
            # crude posterior update, mirroring env
            k_running[e["j"] - 1] = np.clip(
                k_running[e["j"] - 1] + (0.05 if e["y"] else -0.02), 0.02, 0.99)

        ra_list.append(compute_ra(traj, kg, k_before_by_step))
        pvr_list.append(compute_pvr(traj, kg, k_before_by_step))
        clmr_list.append(compute_clmr(traj))
        acr_list.append(acr)
        gain = compute_nlg(pre, max(pre, post))
        if gain is not None:
            nlg_list.append(gain)
    return {
        "RA": float(np.mean(ra_list)),
        "NLG": float(np.mean(nlg_list)) if nlg_list else 0.0,
        "PVR": float(np.mean(pvr_list)),
        "ACR": float(np.mean(acr_list)),
        "CLMR": float(np.mean(clmr_list)),
    }
