"""
Curriculum knowledge graph G = (V, E, W) with n = 68 knowledge points and
153 prerequisite edges (section 3.5). Provides prerequisite lookup, the
out-degree based weight v_j of Eq. (13) and the edge weight w_ij used in
Eq. (14).
"""

import numpy as np

import config


class KnowledgeGraph:
    """
    Read prerequisite edges from an ECTEData instance and build the
    lookup tables the reward and mask modules need.
    """

    def __init__(self, data):
        self.n = data.n_kp  # 68
        self.prereqs = {j: [] for j in range(1, self.n + 1)}      # list of (i, w)
        for _, row in data.prerequisites.iterrows():
            self.prereqs[int(row["to_kp"])].append(
                (int(row["from_kp"]), float(row["strength"])))
        # Out degree
        self.out_deg = np.zeros(self.n + 1, dtype=int)  # index 1..n
        for _, row in data.prerequisites.iterrows():
            self.out_deg[int(row["from_kp"])] += 1
        # v_j = (1 + d^+_j) / sum_i(1 + d^+_i)   Eq. (13)
        v_raw = 1.0 + self.out_deg[1:]                  # shape (n,)
        self.v = v_raw / v_raw.sum()                    # shape (n,) sums to 1
        self.v_max = float(self.v.max())

    def prerequisite_set(self, j):
        """Return list of (prerequisite KP, weight) for the target KP j."""
        return self.prereqs[j]

    def all_prereq_satisfied(self, j, k_vec):
        """
        Fraction of satisfied prerequisites for target KP j, weighted by w_ij.
        k_vec is a length-n mastery vector (indexed 0..n-1).
        Returns (numerator / denominator) in [0, 1]; if no prerequisite, 1.
        """
        prs = self.prereqs[j]
        if not prs:
            return 1.0
        num = 0.0
        den = 0.0
        for i, w in prs:
            den += w
            if k_vec[i - 1] >= config.K_PRE:
                num += w
        return num / den if den > 0 else 1.0

    def path_reward(self, j, k_vec):
        """Eq. (14): R_path = 2 * fraction - 1, in [-1, 1]."""
        return 2.0 * self.all_prereq_satisfied(j, k_vec) - 1.0
