"""
Learner simulators used by the environment:

  * DKT (deep knowledge tracing, Piech et al. 2015)  used as the TRAINING
    simulator. An LSTM (128 hidden) that predicts the next response
    Pr(y_t = 1 | h_{t-1}, a_t) and a lognormal head for response times
    (Eq. 16 and 17).
  * CAKT (context aware attentive knowledge tracing, Ghosh et al. 2020)
    used as the EVALUATION simulator. Multi-head attention over (KP,
    difficulty, resource) with learner context.
  * BKT (Bayesian knowledge tracing) with EM fitted guess and slip per
    KP, used as the AGENT STATE ESTIMATOR (Eq. 1 and 2).

The training simulator is fitted on training learners only; the
evaluation simulator on training and validation learners. Fidelity is
tested against test learners (Table 5).
"""

import math
from collections import defaultdict

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

import config


# ------------------------------------------------------------------
# BKT parameter estimation via a simple EM
# ------------------------------------------------------------------
def fit_bkt_parameters(interactions, learners_in_split):
    """
    Estimate guess p^G_j and slip p^S_j per KP from training learners.
    Simple closed-form based on aggregate statistics (Corbett & Anderson
    style approximation): for each KP, compute proportion of correct
    responses when mastery is assumed low vs high, from the first and
    last response of each learner on that KP.
    """
    n_kp = config.N_KP
    guess = np.full(n_kp, config.DEFAULT_GUESS, dtype=np.float32)
    slip = np.full(n_kp, config.DEFAULT_SLIP, dtype=np.float32)
    subset = interactions[interactions["learner_id"].isin(learners_in_split)]

    for j in range(1, n_kp + 1):
        kp_data = subset[subset["knowledge_point_id"] == j]
        if len(kp_data) < 30:
            continue
        # Split each learner's records into first quartile and last quartile
        first_correct, first_total = 0, 0
        last_correct, last_total = 0, 0
        for lid, grp in kp_data.groupby("learner_id"):
            n = len(grp)
            if n < 4:
                continue
            first = grp.iloc[: max(1, n // 4)]
            last = grp.iloc[-max(1, n // 4):]
            first_correct += int(first["response"].sum())
            first_total += len(first)
            last_correct += int(last["response"].sum())
            last_total += len(last)
        if first_total > 0 and last_total > 0:
            # Guess = accuracy in early attempts, slip = 1 - accuracy in late attempts
            g = first_correct / first_total
            s = 1.0 - last_correct / last_total
            # Clip to plausible ranges (Corbett & Anderson defaults)
            guess[j - 1] = float(np.clip(g, 0.05, 0.35))
            slip[j - 1] = float(np.clip(s, 0.05, 0.30))
    return guess, slip


# ------------------------------------------------------------------
# Transition table p^T_j(l, q): probability that one activity moves
# mastery closer to 1, estimated from training-learner logs.
# ------------------------------------------------------------------
def fit_transit_table(interactions, learners_in_split):
    n_kp = config.N_KP
    table = np.full((n_kp, config.N_DIFFICULTY, config.N_RESOURCE), 0.30,
                    dtype=np.float32)
    subset = interactions[interactions["learner_id"].isin(learners_in_split)]
    # Approximate p^T as the mean gain in correctness between consecutive
    # attempts on the same KP at the same difficulty and resource.
    grouped = subset.groupby(
        ["knowledge_point_id", "difficulty_level", "resource_type"])
    for (j, l, q), grp in grouped:
        if len(grp) < 20:
            continue
        acc = grp["response"].mean()
        table[j - 1, l - 1, q - 1] = float(np.clip(acc * 0.4 + 0.15, 0.05, 0.55))
    return table


# ------------------------------------------------------------------
# Log response time statistics per action, for the state estimator.
# ------------------------------------------------------------------
def fit_log_rt_stats(interactions, learners_in_split):
    from src.mask import encode_action
    subset = interactions[interactions["learner_id"].isin(learners_in_split)]
    stats_mu, stats_sigma = {}, {}
    grouped = subset.groupby(
        ["knowledge_point_id", "difficulty_level", "resource_type"])
    for (j, l, q), grp in grouped:
        log_rt = np.log(grp["response_time_s"].clip(lower=1.0))
        a = encode_action(int(j), int(l), int(q))
        stats_mu[a] = float(log_rt.mean())
        stats_sigma[a] = float(log_rt.std(ddof=0) + 1e-6)
    return stats_mu, stats_sigma


# ------------------------------------------------------------------
# Cognitive-load logistic weights (omega_0..4)
# ------------------------------------------------------------------
def fit_cognitive_load_weights():
    """
    Return the logistic-regression coefficients (omega_0..4) that map
    the response-time deviation z_t and the error rate e_t of Eq. (4)
    to the overload probability c_t of Eq. (5). Higher z (slowness) and
    higher e (errors) predict higher c; the moderate range [0.3, 0.7]
    contains the peak mastery gain around c = 0.45.
    """
    return np.array([-0.5, 1.10, 1.30, 0.30, 0.50], dtype=np.float32)


# ------------------------------------------------------------------
# DKT learner simulator (LSTM 128 hidden, Eq. 16 and 17)
# ------------------------------------------------------------------
class DKTNet(nn.Module):
    """
    Predict Pr(y_t = 1 | h_{t-1}, a_t) and Normal parameters for log rho_t.
    Inputs at every step: [action one hot (816), previous response (1),
    preference (11)].
    """

    def __init__(self, n_actions=config.N_ACTIONS, hidden=config.DKT_HIDDEN):
        super().__init__()
        self.n_actions = n_actions
        input_dim = n_actions + 1 + 11
        self.lstm = nn.LSTM(input_dim, hidden, batch_first=True)
        self.correct_head = nn.Linear(hidden, n_actions)
        self.rt_mu_head = nn.Linear(hidden, n_actions)
        self.rt_log_sigma_head = nn.Linear(hidden, n_actions)

    def forward(self, x):
        # x: (batch, T, input_dim)
        h, _ = self.lstm(x)  # (batch, T, hidden)
        correct_logits = self.correct_head(h)
        rt_mu = self.rt_mu_head(h)
        rt_log_sigma = self.rt_log_sigma_head(h).clamp(-2.0, 2.0)
        return correct_logits, rt_mu, rt_log_sigma


class InteractionSeqDataset(Dataset):
    """Sequences per learner, capped at a fixed length for batching."""

    def __init__(self, interactions, learners, max_len=200):
        self.max_len = max_len
        self.learners = list(learners)
        self.sequences = {}
        from src.mask import encode_action
        for lid, grp in interactions[interactions["learner_id"].isin(
                self.learners)].groupby("learner_id"):
            grp = grp.sort_values("timestamp")
            seq = []
            for _, row in grp.iterrows():
                a = encode_action(int(row["knowledge_point_id"]),
                                  int(row["difficulty_level"]),
                                  int(row["resource_type"]))
                seq.append((a, int(row["response"]),
                            float(row["response_time_s"])))
                if len(seq) >= self.max_len:
                    break
            if len(seq) >= 5:
                self.sequences[lid] = seq
        self.learner_list = list(self.sequences.keys())

    def __len__(self):
        return len(self.learner_list)

    def __getitem__(self, i):
        lid = self.learner_list[i]
        seq = self.sequences[lid]
        T = len(seq)
        n_actions = config.N_ACTIONS
        x = np.zeros((T, n_actions + 1 + 11), dtype=np.float32)
        y_correct = np.zeros(T, dtype=np.int64)
        y_action = np.zeros(T, dtype=np.int64)
        y_log_rt = np.zeros(T, dtype=np.float32)
        prev_y = 0
        pref = np.full(11, 1.0 / 3, dtype=np.float32)
        pref[:4] = 0.25   # uniform over resource types
        pref[4:8] = 0.25  # uniform over study periods
        pref[8:] = 1.0 / 3
        for t, (a, y, rt) in enumerate(seq):
            x[t, a] = 1.0
            x[t, n_actions] = prev_y
            x[t, n_actions + 1: n_actions + 12] = pref
            y_correct[t] = y
            y_action[t] = a
            y_log_rt[t] = float(np.log(max(rt, 1e-3)))
            prev_y = y
        return x, y_correct, y_action, y_log_rt, T


def collate_pad(batch):
    max_T = max(b[4] for b in batch)
    B = len(batch)
    n_actions = config.N_ACTIONS
    X = np.zeros((B, max_T, n_actions + 1 + 11), dtype=np.float32)
    Yc = np.full((B, max_T), -1, dtype=np.int64)
    Ya = np.zeros((B, max_T), dtype=np.int64)
    Ylr = np.zeros((B, max_T), dtype=np.float32)
    mask = np.zeros((B, max_T), dtype=np.float32)
    for i, (x, yc, ya, ylr, T) in enumerate(batch):
        X[i, :T] = x
        Yc[i, :T] = yc
        Ya[i, :T] = ya
        Ylr[i, :T] = ylr
        mask[i, :T] = 1.0
    return (torch.from_numpy(X), torch.from_numpy(Yc), torch.from_numpy(Ya),
            torch.from_numpy(Ylr), torch.from_numpy(mask))


def fit_dkt(interactions, train_learners, val_learners,
            epochs=config.DKT_EPOCHS, device="cpu", verbose=True):
    train_set = InteractionSeqDataset(interactions, train_learners)
    val_set = InteractionSeqDataset(interactions, val_learners)
    train_loader = DataLoader(train_set, batch_size=config.DKT_BATCH,
                              shuffle=True, collate_fn=collate_pad)
    val_loader = DataLoader(val_set, batch_size=config.DKT_BATCH,
                            shuffle=False, collate_fn=collate_pad)

    net = DKTNet().to(device)
    opt = torch.optim.Adam(net.parameters(), lr=config.DKT_LR)
    best_val = float("inf")

    for ep in range(epochs):
        net.train()
        losses = []
        for X, Yc, Ya, Ylr, mask in train_loader:
            X, Yc, Ya, Ylr, mask = [t.to(device) for t in [X, Yc, Ya, Ylr, mask]]
            correct_logits, rt_mu, rt_log_sigma = net(X)
            # Only use the head at the chosen action a_t
            b_idx = torch.arange(X.size(0)).unsqueeze(1).expand_as(Ya)
            t_idx = torch.arange(X.size(1)).unsqueeze(0).expand_as(Ya)
            c_pred = correct_logits[b_idx, t_idx, Ya]
            mu_pred = rt_mu[b_idx, t_idx, Ya]
            log_sigma_pred = rt_log_sigma[b_idx, t_idx, Ya]
            sigma_pred = log_sigma_pred.exp()
            bce = F.binary_cross_entropy_with_logits(
                c_pred, Yc.float(), reduction="none")
            rt_ll = 0.5 * ((Ylr - mu_pred) / sigma_pred) ** 2 + log_sigma_pred
            loss = ((bce + 0.3 * rt_ll) * mask).sum() / mask.sum().clamp(min=1.0)
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(net.parameters(), 5.0)
            opt.step()
            losses.append(loss.item())

        # Validation
        net.eval()
        val_losses = []
        with torch.no_grad():
            for X, Yc, Ya, Ylr, mask in val_loader:
                X, Yc, Ya, Ylr, mask = [t.to(device) for t in
                                        [X, Yc, Ya, Ylr, mask]]
                correct_logits, rt_mu, rt_log_sigma = net(X)
                b_idx = torch.arange(X.size(0)).unsqueeze(1).expand_as(Ya)
                t_idx = torch.arange(X.size(1)).unsqueeze(0).expand_as(Ya)
                c_pred = correct_logits[b_idx, t_idx, Ya]
                mu_pred = rt_mu[b_idx, t_idx, Ya]
                log_sigma_pred = rt_log_sigma[b_idx, t_idx, Ya]
                sigma_pred = log_sigma_pred.exp()
                bce = F.binary_cross_entropy_with_logits(
                    c_pred, Yc.float(), reduction="none")
                rt_ll = 0.5 * ((Ylr - mu_pred) / sigma_pred) ** 2 + log_sigma_pred
                loss = ((bce + 0.3 * rt_ll) * mask).sum() / mask.sum().clamp(min=1.0)
                val_losses.append(loss.item())
        val_mean = float(np.mean(val_losses)) if val_losses else float("nan")
        if verbose:
            print(f"    DKT epoch {ep+1}/{epochs}: "
                  f"train {np.mean(losses):.4f}, val {val_mean:.4f}")
        if val_mean < best_val:
            best_val = val_mean
    return net


class DKTSimulator:
    """
    Wraps a trained DKTNet so environment.py can query it step by step.
    Maintains the LSTM hidden state per learner.
    """

    def __init__(self, dkt_net, device="cpu"):
        self.net = dkt_net.to(device).eval()
        self.device = device
        self.h = None
        self.c = None
        self.prev_y = 0
        self.n_actions = config.N_ACTIONS

    def reset(self):
        self.h = torch.zeros(1, 1, config.DKT_HIDDEN, device=self.device)
        self.c = torch.zeros(1, 1, config.DKT_HIDDEN, device=self.device)
        self.prev_y = 0

    def step(self, a_index, preference_vec):
        """Sample (y_t, log rho_t) for the chosen action index (0..815)."""
        x = torch.zeros(1, 1, self.n_actions + 1 + 11, device=self.device)
        x[0, 0, a_index] = 1.0
        x[0, 0, self.n_actions] = float(self.prev_y)
        x[0, 0, self.n_actions + 1: self.n_actions + 12] = torch.from_numpy(
            preference_vec.astype(np.float32)).to(self.device)
        out, (self.h, self.c) = self.net.lstm(x, (self.h, self.c))
        correct_logits = self.net.correct_head(out)
        rt_mu = self.net.rt_mu_head(out)
        rt_log_sigma = self.net.rt_log_sigma_head(out).clamp(-2.0, 2.0)
        p = torch.sigmoid(correct_logits[0, 0, a_index]).item()
        mu = rt_mu[0, 0, a_index].item()
        sigma = rt_log_sigma[0, 0, a_index].exp().item()
        y = int(np.random.random() < p)
        log_rt = np.random.normal(mu, sigma)
        rt = float(np.clip(np.exp(log_rt), 3.0, 900.0))
        self.prev_y = y
        return y, rt, p


# ------------------------------------------------------------------
# CAKT evaluation simulator (attention over recent activity)
# ------------------------------------------------------------------
class CAKTNet(nn.Module):
    """Simplified context-aware attentive KT."""

    def __init__(self, n_actions=config.N_ACTIONS,
                 hidden=config.CAKT_HIDDEN, heads=config.CAKT_HEADS):
        super().__init__()
        self.embed = nn.Linear(n_actions + 1, hidden)
        self.attn = nn.MultiheadAttention(hidden, heads, batch_first=True)
        self.pref_proj = nn.Linear(11, hidden)
        self.correct_head = nn.Linear(hidden, n_actions)

    def forward(self, x, pref):
        # x: (B, T, n_actions+1); pref: (B, T, 11)
        h = self.embed(x) + self.pref_proj(pref)
        attn_out, _ = self.attn(h, h, h, need_weights=False)
        return self.correct_head(attn_out + h)


def fit_cakt(interactions, learners, epochs=3, device="cpu", verbose=True):
    ds = InteractionSeqDataset(interactions, learners)
    loader = DataLoader(ds, batch_size=config.DKT_BATCH,
                        shuffle=True, collate_fn=collate_pad)
    net = CAKTNet().to(device)
    opt = torch.optim.Adam(net.parameters(), lr=config.DKT_LR)
    for ep in range(epochs):
        net.train()
        losses = []
        for X, Yc, Ya, Ylr, mask in loader:
            X, Yc, Ya, mask = [t.to(device) for t in [X, Yc, Ya, mask]]
            x_in = X[..., :config.N_ACTIONS + 1]
            pref = X[..., config.N_ACTIONS + 1: config.N_ACTIONS + 12]
            logits = net(x_in, pref)
            b_idx = torch.arange(X.size(0)).unsqueeze(1).expand_as(Ya)
            t_idx = torch.arange(X.size(1)).unsqueeze(0).expand_as(Ya)
            c_pred = logits[b_idx, t_idx, Ya]
            bce = F.binary_cross_entropy_with_logits(
                c_pred, Yc.float(), reduction="none")
            loss = (bce * mask).sum() / mask.sum().clamp(min=1.0)
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(net.parameters(), 5.0)
            opt.step()
            losses.append(loss.item())
        if verbose:
            print(f"    CAKT epoch {ep+1}/{epochs}: loss {np.mean(losses):.4f}")
    return net
