"""
Load the raw ECTE dataset (dataset/*.csv) into memory.

Every access point returns a pandas DataFrame indexed for fast lookup.
The loader also stratifies learners into five folds by baseline mastery.
"""

from pathlib import Path

import numpy as np
import pandas as pd

import config


class ECTEData:
    """Container for the ECTE dataset and the cross validation folds."""

    def __init__(self, dataset_dir: Path = None):
        self.dir = Path(dataset_dir) if dataset_dir else config.DATASET_DIR
        self.interactions = pd.read_csv(self.dir / "interactions.csv")
        self.learners = pd.read_csv(self.dir / "learners.csv")
        self.knowledge_points = pd.read_csv(self.dir / "knowledge_points.csv")
        self.prerequisites = pd.read_csv(self.dir / "prerequisites.csv")
        self.items = pd.read_csv(self.dir / "items.csv")
        self.courses = pd.read_csv(self.dir / "courses.csv")
        self.annotator_ratings = pd.read_csv(self.dir / "annotator_ratings.csv")

        self.n_kp = len(self.knowledge_points)
        self.n_items = len(self.items)
        self.learner_ids = self.learners["learner_id"].tolist()

        # Speedup indices
        self.interactions.sort_values(["learner_id", "timestamp"], inplace=True)
        self.interactions.reset_index(drop=True, inplace=True)
        self.item_lookup = self.items.set_index("item_id").to_dict("index")

        # KP anchor by course
        self.course_kp_pool = {
            "C1": list(range(1, 15)) + list(range(15, 20)),
            "C2": list(range(1, 15)) + list(range(20, 37)),
            "C3": list(range(1, 15)) + list(range(37, 55)),
            "C4": list(range(1, 15)) + list(range(55, 69)),
        }

    # ------------------------------------------------------------------
    # Cross validation
    # ------------------------------------------------------------------
    def stratified_folds(self, n_folds: int = 5, seed: int = 0):
        """
        Learner-level five-fold cross validation stratified by baseline
        mastery group (low, medium, high). Returns a list of dicts with
        train / validation / test learner_id sets, per fold.
        """
        rng = np.random.default_rng(seed)
        m = self.learners["baseline_mastery"].to_numpy()
        # Groups: low < 0.35, medium 0.35 to 0.65, high > 0.65
        group = np.where(m < 0.35, 0, np.where(m <= 0.65, 1, 2))
        folds = []
        # Shuffle inside each group, then round-robin distribute
        assignments = np.empty(len(self.learners), dtype=int)
        for g in [0, 1, 2]:
            idx = np.where(group == g)[0]
            rng.shuffle(idx)
            for pos, i in enumerate(idx):
                assignments[i] = pos % n_folds
        for f in range(n_folds):
            test_idx = np.where(assignments == f)[0]
            val_idx = np.where(assignments == (f + 1) % n_folds)[0]
            train_idx = np.setdiff1d(np.arange(len(self.learners)),
                                     np.concatenate([test_idx, val_idx]))
            folds.append({
                "train": set(self.learners.iloc[train_idx]["learner_id"]),
                "val": set(self.learners.iloc[val_idx]["learner_id"]),
                "test": set(self.learners.iloc[test_idx]["learner_id"]),
            })
        return folds


if __name__ == "__main__":
    data = ECTEData()
    print(f"Interactions: {len(data.interactions):,}")
    print(f"Learners: {len(data.learners)}")
    print(f"KP: {data.n_kp}, Items: {data.n_items}")
    folds = data.stratified_folds(config.N_FOLDS, seed=0)
    for i, f in enumerate(folds):
        print(f"  Fold {i}: train {len(f['train'])}, val {len(f['val'])}, "
              f"test {len(f['test'])}")
