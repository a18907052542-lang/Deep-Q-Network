"""
Six evaluation metrics of Table 4:

  RA (%)   : share of decisions whose (j, l, q) satisfies mastery,
             prerequisites and difficulty band under the LATENT state
  NLG (%)  : normalised learning gain = (Post - Pre) / (100 - Pre) on
             the held-out pool, averaged over test learners
  PVR (%)  : share of recommendations violating at least one prerequisite
  ACR      : undiscounted sum of r_t over an episode, averaged over
             test learners
  CLMR (%) : share of steps whose next c_{t+1} lies in [0.3, 0.7]
  CE       : first episode after which the 50 episode moving average of
             the validation return stays within ±2% of the plateau for
             200 episodes
"""

import numpy as np

import config


def compute_ra(episode_log, kg, k_before_by_step):
    """
    RA per Table 4: decision satisfies mastery, prerequisites and the
    difficulty band matching the mastery.
    """
    n_valid = 0
    n_total = 0
    for step, entry in enumerate(episode_log):
        j = entry["j"]
        l = entry["l"]
        k = k_before_by_step[step]
        n_total += 1
        # Mastery below threshold?
        if k[j - 1] >= config.K_MAS:
            continue
        # Prerequisites satisfied?
        prs = kg.prerequisite_set(j)
        ok_pre = all(k[i - 1] >= config.K_PRE for i, _ in prs)
        if not ok_pre:
            continue
        # Difficulty band matching mastery
        m = k[j - 1]
        if m < 0.35:
            tgt = 1
        elif m < 0.60:
            tgt = 2
        else:
            tgt = 3
        if l == tgt:
            n_valid += 1
    return 100.0 * n_valid / max(n_total, 1)


def compute_pvr(episode_log, kg, k_before_by_step):
    """Share of steps whose recommended KP has at least one unmet prereq."""
    n_bad = 0
    n_total = 0
    for step, entry in enumerate(episode_log):
        j = entry["j"]
        k = k_before_by_step[step]
        prs = kg.prerequisite_set(j)
        n_total += 1
        if any(k[i - 1] < config.K_PRE for i, _ in prs):
            n_bad += 1
    return 100.0 * n_bad / max(n_total, 1)


def compute_clmr(episode_log):
    """Share of steps whose next c_{t+1} lies in [0.3, 0.7]."""
    n = len(episode_log)
    if n == 0:
        return 0.0
    ok = sum(1 for e in episode_log if config.C_L <= e.get("c_next", 0.5) <= config.C_U)
    return 100.0 * ok / n


def compute_nlg(pretest_score, posttest_score):
    """(Post - Pre) / (100 - Pre); Pre in [0, 100]."""
    if pretest_score >= 99.0:
        return None
    return 100.0 * (posttest_score - pretest_score) / (100.0 - pretest_score)


def compute_ce(validation_returns):
    """First episode after which the 50-episode moving average stays
    within ±2% of the plateau for 200 episodes."""
    if len(validation_returns) < 500:
        return None
    arr = np.asarray(validation_returns, dtype=np.float32)
    plateau = arr[-500:].mean()
    tol = 0.02 * abs(plateau)
    ma = np.convolve(arr, np.ones(50) / 50, mode="valid")
    for i in range(len(ma) - 200):
        window = ma[i:i + 200]
        if np.all(np.abs(window - plateau) <= tol):
            return i + 50  # convert convolution offset back to episode
    return None
