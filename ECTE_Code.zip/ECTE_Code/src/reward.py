"""
Composite reward r_t = 100 * (lambda_1 * R_know + lambda_2 * R_path
                              + lambda_3 * R_cog)   (Eq. 12).

Each component is normalised to [-1, 1] so r_t sits in [-100, 100].
"""

import numpy as np

import config


def r_knowledge(delta_k_vec, v_vec, v_max):
    """
    Eq. (13). delta_k_vec is a length-n array of (k_{t+1,j} - k_{t,j}).
    v_vec is the length-n out-degree weight vector v_j.
    """
    weighted = float(np.sum(v_vec * delta_k_vec))
    normalised = weighted / (v_max * config.DELTA_MAX)
    return float(np.clip(normalised - config.STEP_COST_NU, -1.0, 1.0))


def r_path(j, k_vec, kg):
    """Eq. (14) via the knowledge-graph helper."""
    return kg.path_reward(j, k_vec)


def r_cognitive(c_next):
    """Eq. (15). Linear penalty scaled by Delta_c to [-1, 1]."""
    if config.C_L <= c_next <= config.C_U:
        return 1.0
    if c_next < config.C_L:
        dist = config.C_L - c_next
    else:
        dist = c_next - config.C_U
    return float(1.0 - 2.0 * min(1.0, dist / config.DELTA_C))


def composite_reward(delta_k_vec, j, k_vec, c_next, kg,
                     lambda_1=config.LAMBDA_1,
                     lambda_2=config.LAMBDA_2,
                     lambda_3=config.LAMBDA_3):
    r_k = r_knowledge(delta_k_vec, kg.v, kg.v_max)
    r_p = r_path(j, k_vec, kg)
    r_c = r_cognitive(c_next)
    return 100.0 * (lambda_1 * r_k + lambda_2 * r_p + lambda_3 * r_c), \
           {"R_know": r_k, "R_path": r_p, "R_cog": r_c}
