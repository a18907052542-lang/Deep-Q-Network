"""Base class for the value-based DRL agents (DQN family and ID3QN)."""

import copy
import math

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

import config
from src.networks import QNetwork, DuelingQNetwork, aggregate_q
from src.replay_buffer import PERBuffer, UniformBuffer


class ValueAgent:
    """Common training loop. Subclasses override _select_target and
    _select_action_masked to swap in Double, Dueling, PER and the
    ID3QN-specific mask logic."""

    name = "base"

    def __init__(self, device="cpu", use_dueling=False, use_per=False):
        self.device = device
        self.use_dueling = use_dueling
        self.use_per = use_per
        self.online = (DuelingQNetwork() if use_dueling
                       else QNetwork()).to(device)
        self.target = copy.deepcopy(self.online).to(device)
        for p in self.target.parameters():
            p.requires_grad = False
        self.opt = torch.optim.Adam(self.online.parameters(),
                                    lr=config.LEARNING_RATE)
        self.buf = PERBuffer() if use_per else UniformBuffer()
        self.eps = config.EPS_START
        self.beta = config.PER_BETA_START
        self.step_count = 0

    # ---------------- Q-value helper (with mask) ----------------
    def _q_values(self, s_batch, mask_batch, net):
        """Return Q(s, a) for the batch. Mask applied in aggregation for
        dueling; standard for plain Q-networks (invalid actions -> -inf)."""
        if self.use_dueling:
            v, a = net(s_batch)
            return aggregate_q(v, a, mask_batch)
        else:
            q = net(s_batch)
            q = q.masked_fill(~mask_batch, float("-inf"))
            return q

    # ---------------- Action selection ----------------
    def act(self, s, mask):
        """Epsilon-greedy over the valid action set."""
        if np.random.random() < self.eps:
            valid_idx = np.where(mask)[0]
            if len(valid_idx) == 0:
                return 0
            return int(np.random.choice(valid_idx))
        with torch.no_grad():
            s_t = torch.from_numpy(s).float().unsqueeze(0).to(self.device)
            m_t = torch.from_numpy(mask).bool().unsqueeze(0).to(self.device)
            q = self._q_values(s_t, m_t, self.online)
            return int(q.argmax(dim=1).item())

    def greedy_act(self, s, mask):
        with torch.no_grad():
            s_t = torch.from_numpy(s).float().unsqueeze(0).to(self.device)
            m_t = torch.from_numpy(mask).bool().unsqueeze(0).to(self.device)
            q = self._q_values(s_t, m_t, self.online)
            return int(q.argmax(dim=1).item())

    # ---------------- Target computation ----------------
    def _compute_target(self, batch):
        s2 = batch["s2"].to(self.device)
        m2 = batch["mask2"].to(self.device).bool()
        r = batch["r"].to(self.device)
        d = batch["done"].to(self.device)
        # Standard: target Q with target network, argmax with target too
        with torch.no_grad():
            q2 = self._q_values(s2, m2, self.target)
            q2 = q2.max(dim=1).values
            q2 = torch.where(torch.isinf(q2), torch.zeros_like(q2), q2)
        return r + config.DISCOUNT * (1 - d) * q2

    # ---------------- One update step ----------------
    def update(self):
        if len(self.buf) < config.LEARNING_START:
            return None
        batch = self.buf.sample(config.MINIBATCH, self.beta)
        if batch is None:
            return None
        s = batch["s"].to(self.device)
        a = batch["a"].to(self.device)
        m = torch.ones(s.size(0), config.N_ACTIONS,
                       dtype=torch.bool, device=self.device)
        q_pred = self._q_values(s, m, self.online).gather(
            1, a.unsqueeze(1)).squeeze(1)
        q_tar = self._compute_target(batch)
        td = q_tar - q_pred
        w = batch["weights"].to(self.device)
        huber = F.smooth_l1_loss(q_pred, q_tar, reduction="none")
        loss = (w * huber).mean()

        self.opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.online.parameters(),
                                       config.GRAD_CLIP)
        self.opt.step()

        # Update priorities and target network
        self.buf.update_priorities(
            batch["indices"], td.detach().cpu().numpy(),
            batch["breakthrough"].cpu().numpy()
            if self.use_per else np.zeros(len(batch["indices"])))
        with torch.no_grad():
            for tp, op in zip(self.target.parameters(),
                              self.online.parameters()):
                tp.data.mul_(1 - config.SOFT_UPDATE_TAU)
                tp.data.add_(config.SOFT_UPDATE_TAU * op.data)
        self.step_count += 1
        return float(loss.item())

    # ---------------- Schedules ----------------
    def anneal(self, episode, total_episodes):
        # eps decay
        if episode <= config.EPS_DECAY_EPISODES:
            frac = episode / config.EPS_DECAY_EPISODES
            self.eps = config.EPS_START + (
                config.EPS_END - config.EPS_START) * frac
        else:
            self.eps = config.EPS_END
        # beta annealing (PER)
        frac = min(episode / total_episodes, 1.0)
        self.beta = config.PER_BETA_START + (
            config.PER_BETA_END - config.PER_BETA_START) * frac

    def push(self, s, a, r, s_next, done, mask_next, breakthrough):
        self.buf.push(s, a, r, s_next, done, mask_next, breakthrough)
