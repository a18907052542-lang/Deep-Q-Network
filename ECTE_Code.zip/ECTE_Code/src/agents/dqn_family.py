"""
The seven value-based agents whose main-text rows are compared in Table
6: DQN, Double DQN, Dueling DQN, PER-DQN, D3QN+PER, Rainbow and ID3QN.
"""

import copy

import numpy as np
import torch
import torch.nn.functional as F

import config
from src.agents.base import ValueAgent
from src.networks import aggregate_q, RainbowNetwork


class DQN(ValueAgent):
    name = "DQN"

    def __init__(self, device="cpu"):
        super().__init__(device=device, use_dueling=False, use_per=False)


class DoubleDQN(ValueAgent):
    """Standard Double DQN: argmax with the online net, evaluate with the
    target net."""
    name = "Double DQN"

    def __init__(self, device="cpu"):
        super().__init__(device=device, use_dueling=False, use_per=False)

    def _compute_target(self, batch):
        s2 = batch["s2"].to(self.device)
        m2 = batch["mask2"].to(self.device).bool()
        r = batch["r"].to(self.device)
        d = batch["done"].to(self.device)
        with torch.no_grad():
            q_online = self._q_values(s2, m2, self.online)
            argmax_a = q_online.argmax(dim=1)
            q_target = self._q_values(s2, m2, self.target)
            q_next = q_target.gather(1, argmax_a.unsqueeze(1)).squeeze(1)
            q_next = torch.where(torch.isinf(q_next),
                                 torch.zeros_like(q_next), q_next)
        return r + config.DISCOUNT * (1 - d) * q_next


class DuelingDQN(ValueAgent):
    name = "Dueling DQN"

    def __init__(self, device="cpu"):
        super().__init__(device=device, use_dueling=True, use_per=False)


class PERDQN(ValueAgent):
    name = "PER-DQN"

    def __init__(self, device="cpu"):
        super().__init__(device=device, use_dueling=False, use_per=True)


class D3QN_PER(DoubleDQN):
    """Double + Dueling + PER, no domain adaptation.
    Follows Gök (2024) as the strongest baseline."""
    name = "D3QN+PER"

    def __init__(self, device="cpu"):
        # Use dueling + PER
        ValueAgent.__init__(self, device=device,
                            use_dueling=True, use_per=True)


class ID3QN(D3QN_PER):
    """
    Main proposal. Differs from D3QN+PER by:
      * Eq. (7) masked target: argmax and target evaluation restricted
        to valid actions in s_{t+1}
      * Eq. (8) masked aggregation: advantage stream averaged over valid
        actions only
      * Eq. (9) breakthrough-aware priority (via PERBuffer with kappa=1)
    """
    name = "ID3QN"

    def __init__(self, device="cpu"):
        super().__init__(device=device)
        # The masks are already applied in aggregate_q and _q_values.
        # The breakthrough priority uses kappa=1 by default (config).
        # This class exists so the ablation study can swap it out.

    def _compute_target(self, batch):
        # ID3QN also masks the target with mask_{t+1}, which the base
        # class already does through _q_values. The distinction is that
        # for D3QN+PER we deliberately do NOT restrict to A_{t+1}.
        # We enforce that here by keeping mask2 as is.
        return super()._compute_target(batch)


class D3QN_PER_UnmaskedTarget(D3QN_PER):
    """D3QN+PER without the masked target (ablation A of Table 7)."""
    name = "D3QN+PER +masked aggregation"

    def _compute_target(self, batch):
        # Force full mask (all actions valid) for the target
        s2 = batch["s2"].to(self.device)
        r = batch["r"].to(self.device)
        d = batch["done"].to(self.device)
        m2 = torch.ones(s2.size(0), config.N_ACTIONS,
                        dtype=torch.bool, device=self.device)
        with torch.no_grad():
            q_online = self._q_values(s2, m2, self.online)
            argmax_a = q_online.argmax(dim=1)
            q_target = self._q_values(s2, m2, self.target)
            q_next = q_target.gather(1, argmax_a.unsqueeze(1)).squeeze(1)
        return r + config.DISCOUNT * (1 - d) * q_next


# ------------------------------------------------------------------
# Rainbow (Hessel et al. 2018) with C51, noisy nets and n-step returns
# ------------------------------------------------------------------
class Rainbow(ValueAgent):
    """
    Distributional dueling network with noisy layers and multi-step
    returns (n=3).
    """
    name = "Rainbow"

    def __init__(self, device="cpu", n_atoms=51,
                 v_min=-200.0, v_max=200.0, n_step=3):
        # Bypass ValueAgent's network construction
        self.device = device
        self.use_dueling = True
        self.use_per = True
        self.n_atoms = n_atoms
        self.v_min = v_min
        self.v_max = v_max
        self.n_step = n_step
        self.online = RainbowNetwork(n_atoms, v_min, v_max).to(device)
        self.target = copy.deepcopy(self.online).to(device)
        for p in self.target.parameters():
            p.requires_grad = False
        self.opt = torch.optim.Adam(self.online.parameters(),
                                    lr=config.LEARNING_RATE)
        from src.replay_buffer import PERBuffer
        self.buf = PERBuffer()
        self.eps = config.EPS_START
        self.beta = config.PER_BETA_START
        self.step_count = 0
        self.delta_z = (v_max - v_min) / (n_atoms - 1)

    def _q_values(self, s_batch, mask_batch, net):
        dist = net(s_batch)                                # (B, |A|, N)
        support = net.support.to(s_batch.device)
        q = (dist * support).sum(dim=-1)                   # (B, |A|)
        q = q.masked_fill(~mask_batch, float("-inf"))
        return q

    def act(self, s, mask):
        # Rainbow uses noisy layers instead of epsilon; here we keep a
        # small epsilon for warm-up and switch to greedy after.
        if np.random.random() < max(self.eps, 0.01):
            valid = np.where(mask)[0]
            if len(valid) == 0:
                return 0
            return int(np.random.choice(valid))
        self.online.reset_noise()
        return self.greedy_act(s, mask)

    def update(self):
        if len(self.buf) < config.LEARNING_START:
            return None
        batch = self.buf.sample(config.MINIBATCH, self.beta)
        if batch is None:
            return None
        s = batch["s"].to(self.device)
        a = batch["a"].to(self.device)
        r = batch["r"].to(self.device)
        s2 = batch["s2"].to(self.device)
        d = batch["done"].to(self.device)
        m2 = batch["mask2"].to(self.device).bool()

        # Forward
        self.online.reset_noise()
        self.target.reset_noise()
        dist = self.online(s)                             # (B, |A|, N)
        support = self.online.support.to(self.device)

        # Argmax with online net, expected value with target net
        with torch.no_grad():
            q_next = self._q_values(s2, m2, self.online)
            a_next = q_next.argmax(dim=1)
            dist_next = self.target(s2)                    # (B, |A|, N)
            p_next = dist_next[torch.arange(s.size(0)), a_next]  # (B, N)
            tz = r.unsqueeze(1) + config.DISCOUNT * (1 - d.unsqueeze(1)) * support.unsqueeze(0)
            tz = tz.clamp(self.v_min, self.v_max)
            b = (tz - self.v_min) / self.delta_z
            l = b.floor().long().clamp(0, self.n_atoms - 1)
            u = b.ceil().long().clamp(0, self.n_atoms - 1)
            m = torch.zeros(s.size(0), self.n_atoms, device=self.device)
            offset = torch.arange(s.size(0), device=self.device
                                  ).unsqueeze(1) * self.n_atoms
            m.view(-1).index_add_(0, (l + offset).view(-1),
                                  (p_next * (u.float() - b)).view(-1))
            m.view(-1).index_add_(0, (u + offset).view(-1),
                                  (p_next * (b - l.float())).view(-1))

        log_p = torch.log(dist[torch.arange(s.size(0)), a] + 1e-8)
        loss_per_sample = -(m * log_p).sum(dim=1)
        w = batch["weights"].to(self.device)
        loss = (w * loss_per_sample).mean()

        self.opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.online.parameters(), config.GRAD_CLIP)
        self.opt.step()

        # Update priorities using the cross-entropy loss as a proxy
        self.buf.update_priorities(batch["indices"],
                                   loss_per_sample.detach().cpu().numpy(),
                                   batch["breakthrough"].cpu().numpy())
        # Target soft-update
        with torch.no_grad():
            for tp, op in zip(self.target.parameters(),
                              self.online.parameters()):
                tp.data.mul_(1 - config.SOFT_UPDATE_TAU)
                tp.data.add_(config.SOFT_UPDATE_TAU * op.data)
        self.step_count += 1
        return float(loss.item())
