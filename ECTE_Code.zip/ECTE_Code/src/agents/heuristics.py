"""
Non-learning baselines from Table 6:

  * Random     : uniform over the valid action set
  * Syllabus   : follows the syllabus order (KP index ascending)
  * KT-greedy  : picks least mastered KP whose prerequisites are met
  * SASRec     : reduced to a valid uniform sample (source uses sequential
                 recommendation over exercises; the paper reduces it to a
                 valid-mask baseline for tutoring)
  * Q-learning : tabular Q over K aggregated states
"""

from collections import defaultdict

import numpy as np

import config
from src.mask import decode_action, encode_action


class RandomPolicy:
    name = "Random"

    def __init__(self):
        pass

    def act(self, state_vec, mask):
        valid = np.where(mask)[0]
        return int(np.random.choice(valid)) if len(valid) else 0

    greedy_act = act

    def update(self, *args, **kwargs):
        return None

    def push(self, *args, **kwargs):
        pass

    def anneal(self, *args, **kwargs):
        pass


class SyllabusOrder:
    name = "Syllabus order"

    def act(self, state_vec, mask):
        # Ascending KP order, then difficulty 1..3, then resource 1..4
        valid = np.where(mask)[0]
        if not len(valid):
            return 0
        return int(valid.min())

    greedy_act = act

    def update(self, *args, **kwargs):
        return None

    def push(self, *args, **kwargs):
        pass

    def anneal(self, *args, **kwargs):
        pass


class KTGreedy:
    """Least mastered KP with satisfied prerequisites, difficulty from
    mastery band, resource from population preference."""
    name = "KT-greedy"

    def __init__(self, kg):
        self.kg = kg

    def act(self, state_vec, mask):
        k = state_vec[:config.N_KP]
        # Rank KPs by (mastery ascending) subject to prerequisites
        satisfied_kps = []
        for j in range(1, config.N_KP + 1):
            if k[j - 1] >= config.K_MAS:
                continue
            frac = self.kg.all_prereq_satisfied(j, k)
            if frac >= 0.9:
                satisfied_kps.append(j)
        if not satisfied_kps:
            valid = np.where(mask)[0]
            return int(valid[0]) if len(valid) else 0
        # Pick lowest mastery
        satisfied_kps.sort(key=lambda j: k[j - 1])
        j = satisfied_kps[0]
        m = k[j - 1]
        if m < 0.35:
            l = 1
        elif m < 0.60:
            l = 2
        else:
            l = 3
        # Resource: pick the most preferred available for this KP+difficulty
        pref_res = int(np.argmax(state_vec[config.N_KP: config.N_KP + 4])) + 1
        for q_try in [pref_res, 1, 2, 3, 4]:
            a = encode_action(j, l, q_try)
            if mask[a]:
                return int(a)
        # Fallback: any valid
        valid = np.where(mask)[0]
        return int(valid[0]) if len(valid) else 0

    greedy_act = act

    def update(self, *args, **kwargs):
        return None

    def push(self, *args, **kwargs):
        pass

    def anneal(self, *args, **kwargs):
        pass


class SASRec:
    """
    Self-attentive sequential recommendation reduced to the tutoring
    setting: pick the most-frequently-observed valid action across the
    aggregated log support.
    """
    name = "SASRec"

    def __init__(self, support_vec):
        self.support = support_vec

    def act(self, state_vec, mask):
        valid = np.where(mask)[0]
        if not len(valid):
            return 0
        scores = self.support[valid]
        return int(valid[int(np.argmax(scores))])

    greedy_act = act

    def update(self, *args, **kwargs):
        return None

    def push(self, *args, **kwargs):
        pass

    def anneal(self, *args, **kwargs):
        pass


class TabularQ:
    """
    Q-learning over K aggregated states, K = 128 per Table S9.
    States are aggregated by k-means on the 80-dim vectors.
    """
    name = "Q-learning (aggregated states)"

    def __init__(self, K=128, lr=0.1, gamma=config.DISCOUNT):
        self.K = K
        self.lr = lr
        self.gamma = gamma
        self.eps = config.EPS_START
        self.Q = np.zeros((K, config.N_ACTIONS), dtype=np.float32)
        self.centroids = None

    def fit_centroids(self, states):
        from sklearn.cluster import KMeans
        km = KMeans(n_clusters=self.K, n_init=3, random_state=0)
        km.fit(states)
        self.centroids = km.cluster_centers_

    def state_to_cluster(self, s):
        if self.centroids is None:
            return 0
        d = np.linalg.norm(self.centroids - s, axis=1)
        return int(np.argmin(d))

    def act(self, state_vec, mask):
        c = self.state_to_cluster(state_vec)
        if np.random.random() < self.eps:
            valid = np.where(mask)[0]
            return int(np.random.choice(valid)) if len(valid) else 0
        q = self.Q[c].copy()
        q[~mask] = -np.inf
        return int(np.argmax(q))

    def greedy_act(self, state_vec, mask):
        c = self.state_to_cluster(state_vec)
        q = self.Q[c].copy()
        q[~mask] = -np.inf
        return int(np.argmax(q))

    def update(self, batch=None):
        # Batched update from a small stored transition
        return None

    def push(self, s, a, r, s_next, done, mask_next, breakthrough):
        c = self.state_to_cluster(s)
        c2 = self.state_to_cluster(s_next)
        best_next = np.max(self.Q[c2] * mask_next.astype(np.float32)
                           - (1 - mask_next.astype(np.float32)) * 1e6)
        target = r if done else r + self.gamma * best_next
        self.Q[c, a] += self.lr * (target - self.Q[c, a])

    def anneal(self, episode, total_episodes):
        if episode <= config.EPS_DECAY_EPISODES:
            frac = episode / config.EPS_DECAY_EPISODES
            self.eps = config.EPS_START + (
                config.EPS_END - config.EPS_START) * frac
        else:
            self.eps = config.EPS_END
