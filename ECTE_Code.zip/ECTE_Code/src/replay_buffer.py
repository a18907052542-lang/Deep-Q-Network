"""
Prioritized Experience Replay with the breakthrough indicator of Eq. (9):

    psi_i = (|delta_i| + epsilon_p) * (1 + kappa * b_i)
    P(i)  = psi_i^alpha / sum_k psi_k^alpha

A sum-tree stores the priorities so that sampling with an unnormalised
distribution costs O(log C).
"""

import numpy as np
import torch

import config


class SumTree:
    def __init__(self, capacity):
        self.capacity = capacity
        self.tree = np.zeros(2 * capacity - 1, dtype=np.float64)
        self.size = 0

    def update(self, leaf_idx, value):
        idx = leaf_idx + self.capacity - 1
        delta = value - self.tree[idx]
        self.tree[idx] = value
        while idx > 0:
            idx = (idx - 1) // 2
            self.tree[idx] += delta

    def total(self):
        return self.tree[0]

    def get(self, s):
        idx = 0
        while idx < self.capacity - 1:
            left = 2 * idx + 1
            right = left + 1
            if s <= self.tree[left]:
                idx = left
            else:
                s -= self.tree[left]
                idx = right
        return idx - (self.capacity - 1), self.tree[idx]


class PERBuffer:
    """
    Stores tuples (s, a, r, s_next, done, mask_next, breakthrough).
    """

    def __init__(self, capacity=config.REPLAY_CAPACITY,
                 alpha=config.PER_ALPHA,
                 breakthrough_kappa=config.BREAKTHROUGH_KAPPA):
        self.capacity = capacity
        self.alpha = alpha
        self.kappa = breakthrough_kappa
        self.tree = SumTree(capacity)
        self.data = [None] * capacity
        self.pos = 0
        self.max_priority = 1.0

    def push(self, s, a, r, s_next, done, mask_next, breakthrough):
        entry = (s.astype(np.float32), int(a), float(r),
                 s_next.astype(np.float32), bool(done),
                 mask_next.astype(bool), bool(breakthrough))
        self.data[self.pos] = entry
        # Give new transitions max priority so they are seen at least once
        p_raw = (self.max_priority + config.PER_EPSILON) * (
            1 + self.kappa * (1 if breakthrough else 0))
        p_alpha = p_raw ** self.alpha
        self.tree.update(self.pos, p_alpha)
        self.pos = (self.pos + 1) % self.capacity
        self.tree.size = min(self.tree.size + 1, self.capacity)

    def __len__(self):
        return self.tree.size

    def sample(self, batch_size, beta):
        total = self.tree.total()
        if total <= 0:
            return None
        segment = total / batch_size
        idxs, priorities, samples = [], [], []
        for i in range(batch_size):
            lo = segment * i
            hi = segment * (i + 1)
            s = np.random.uniform(lo, hi)
            idx, p = self.tree.get(s)
            if self.data[idx] is None:
                # Retry with a random slot (edge case at startup)
                idx = np.random.randint(self.tree.size)
                p = max(1e-6, self.tree.tree[idx + self.capacity - 1])
            idxs.append(idx)
            priorities.append(p)
            samples.append(self.data[idx])
        priorities = np.asarray(priorities, dtype=np.float64)
        probs = priorities / total
        # Eq. (10) importance sampling weights
        weights = (self.tree.size * probs) ** (-beta)
        weights /= max(weights.max(), 1e-9)

        # Unpack
        s_arr = np.stack([x[0] for x in samples])
        a_arr = np.asarray([x[1] for x in samples], dtype=np.int64)
        r_arr = np.asarray([x[2] for x in samples], dtype=np.float32)
        s2_arr = np.stack([x[3] for x in samples])
        d_arr = np.asarray([x[4] for x in samples], dtype=np.float32)
        m2_arr = np.stack([x[5] for x in samples])
        b_arr = np.asarray([x[6] for x in samples], dtype=np.float32)

        return {
            "s": torch.from_numpy(s_arr),
            "a": torch.from_numpy(a_arr),
            "r": torch.from_numpy(r_arr),
            "s2": torch.from_numpy(s2_arr),
            "done": torch.from_numpy(d_arr),
            "mask2": torch.from_numpy(m2_arr),
            "breakthrough": torch.from_numpy(b_arr),
            "weights": torch.from_numpy(weights.astype(np.float32)),
            "indices": np.asarray(idxs, dtype=np.int64),
        }

    def update_priorities(self, idxs, td_errors, breakthroughs):
        """Recompute psi_i and refresh the tree."""
        for idx, td, b in zip(idxs, td_errors, breakthroughs):
            p_raw = (abs(float(td)) + config.PER_EPSILON) * (
                1 + self.kappa * (1 if bool(b) else 0))
            p_alpha = p_raw ** self.alpha
            self.tree.update(idx, p_alpha)
            self.max_priority = max(self.max_priority, p_raw)


class UniformBuffer:
    """Vanilla replay for the non-PER baselines."""

    def __init__(self, capacity=config.REPLAY_CAPACITY):
        self.capacity = capacity
        self.data = []
        self.pos = 0

    def push(self, s, a, r, s_next, done, mask_next, breakthrough):
        item = (s.astype(np.float32), int(a), float(r),
                s_next.astype(np.float32), bool(done),
                mask_next.astype(bool))
        if len(self.data) < self.capacity:
            self.data.append(item)
        else:
            self.data[self.pos] = item
            self.pos = (self.pos + 1) % self.capacity

    def __len__(self):
        return len(self.data)

    def sample(self, batch_size, beta=None):
        idxs = np.random.randint(0, len(self.data), size=batch_size)
        samples = [self.data[i] for i in idxs]
        s_arr = np.stack([x[0] for x in samples])
        a_arr = np.asarray([x[1] for x in samples], dtype=np.int64)
        r_arr = np.asarray([x[2] for x in samples], dtype=np.float32)
        s2_arr = np.stack([x[3] for x in samples])
        d_arr = np.asarray([x[4] for x in samples], dtype=np.float32)
        m2_arr = np.stack([x[5] for x in samples])
        return {
            "s": torch.from_numpy(s_arr),
            "a": torch.from_numpy(a_arr),
            "r": torch.from_numpy(r_arr),
            "s2": torch.from_numpy(s2_arr),
            "done": torch.from_numpy(d_arr),
            "mask2": torch.from_numpy(m2_arr),
            "weights": torch.ones(batch_size),
            "indices": idxs,
        }

    def update_priorities(self, idxs, td_errors, breakthroughs):
        pass
