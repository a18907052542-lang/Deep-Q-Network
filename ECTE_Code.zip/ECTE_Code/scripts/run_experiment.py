"""
Full training and evaluation pipeline: fit BKT parameters, transit
tables and log-response-time statistics; fit the DKT training simulator
and the CAKT evaluation simulator; train the seven value-based agents
across the five cross-validation folds and the five seeds; run the
non-learning baselines; write per-fold metrics into outputs/logs.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import json
import time
from collections import defaultdict

import numpy as np
import torch

import config
from src.data_loader import ECTEData
from src.knowledge_graph import KnowledgeGraph
from src.mask import ActionMask
from src.knowledge_tracing import (fit_bkt_parameters, fit_transit_table,
                                   fit_log_rt_stats,
                                   fit_cognitive_load_weights,
                                   fit_dkt, fit_cakt, DKTSimulator)
from src.environment import TutoringEnvironment
from src.agents.dqn_family import (DQN, DoubleDQN, DuelingDQN, PERDQN,
                                   D3QN_PER, ID3QN, Rainbow)
from src.agents.heuristics import (RandomPolicy, SyllabusOrder, KTGreedy,
                                   SASRec)
from src.train import train_agent
from src.evaluate import evaluate_policy


def main():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Device: {device}")

    print("Loading dataset ...")
    data = ECTEData()
    print(f"  Interactions: {len(data.interactions):,}")
    print(f"  Learners: {len(data.learners)}")

    print("Building knowledge graph and action mask ...")
    kg = KnowledgeGraph(data)
    action_mask = ActionMask(data)
    print(f"  KP out-degree v_max = {kg.v_max:.4f}")
    print(f"  Valid base mask cardinality: "
          f"{int(action_mask.base_mask.sum())} / {config.N_ACTIONS}")

    print("Splitting folds ...")
    folds = data.stratified_folds(n_folds=config.N_FOLDS, seed=0)

    all_results = defaultdict(list)

    for fold_i, fold in enumerate(folds):
        print(f"\n===== Fold {fold_i + 1} / {config.N_FOLDS} =====")
        train_lrs = data.learners[data.learners["learner_id"].isin(fold["train"])]
        val_lrs = data.learners[data.learners["learner_id"].isin(fold["val"])]
        test_lrs = data.learners[data.learners["learner_id"].isin(fold["test"])]
        print(f"  train {len(train_lrs)}, val {len(val_lrs)}, test {len(test_lrs)}")

        guess, slip = fit_bkt_parameters(data.interactions, fold["train"])
        transit = fit_transit_table(data.interactions, fold["train"])
        log_rt_mu, log_rt_sigma = fit_log_rt_stats(
            data.interactions, fold["train"])
        omega = fit_cognitive_load_weights()
        agent_bkt = {"guess": guess, "slip": slip, "transit": transit,
                     "log_rt_mu": log_rt_mu, "log_rt_sigma": log_rt_sigma,
                     "omega": omega}

        print("  Fitting DKT training simulator ...")
        dkt_net = fit_dkt(data.interactions, fold["train"], fold["val"],
                          epochs=config.DKT_EPOCHS, device=device)
        dkt_sim = DKTSimulator(dkt_net, device=device)

        print("  Fitting CAKT evaluation simulator ...")
        cakt_net = fit_cakt(data.interactions,
                            list(fold["train"]) + list(fold["val"]),
                            epochs=config.DKT_EPOCHS, device=device)
        cakt_sim = DKTSimulator(dkt_net, device=device)

        train_env = TutoringEnvironment(data, kg, action_mask, dkt_sim,
                                        agent_bkt, course_id="C1")
        eval_env = TutoringEnvironment(data, kg, action_mask, cakt_sim,
                                       agent_bkt, course_id="C1")

        agents_to_run = {
            "DQN":         lambda: DQN(device=device),
            "Double DQN":  lambda: DoubleDQN(device=device),
            "Dueling DQN": lambda: DuelingDQN(device=device),
            "PER-DQN":     lambda: PERDQN(device=device),
            "D3QN+PER":    lambda: D3QN_PER(device=device),
            "Rainbow":     lambda: Rainbow(device=device),
            "ID3QN":       lambda: ID3QN(device=device),
        }

        for seed in config.SEEDS:
            print(f"\n  Seed {seed}")
            torch.manual_seed(seed)
            np.random.seed(seed)

            for name, ctor in agents_to_run.items():
                print(f"    Training {name} ...")
                agent = ctor()
                t0 = time.time()
                _ = train_agent(agent, train_env, train_lrs, val_lrs,
                                total_episodes=config.TOTAL_EPISODES,
                                verbose_every=max(500, config.TOTAL_EPISODES // 6))
                elapsed = time.time() - t0
                m = evaluate_policy(agent, eval_env, test_lrs, kg, seed=seed)
                m["training_time_s"] = round(elapsed, 1)
                m["fold"] = fold_i
                m["seed"] = seed
                all_results[name].append(m)
                print(f"      -> {m}")

            for pol_name, pol in [("Random", RandomPolicy()),
                                  ("Syllabus order", SyllabusOrder()),
                                  ("KT-greedy", KTGreedy(kg)),
                                  ("SASRec", SASRec(action_mask.support))]:
                m = evaluate_policy(pol, eval_env, test_lrs, kg, seed=seed)
                m["fold"] = fold_i
                m["seed"] = seed
                all_results[pol_name].append(m)
                print(f"    {pol_name}: {m}")

    out_path = config.LOGS_DIR / "cross_validation_results.json"
    out_path.write_text(json.dumps(all_results, indent=2))
    print(f"\nResults written to {out_path}")


if __name__ == "__main__":
    main()
