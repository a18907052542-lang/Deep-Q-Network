"""
Write the six evaluation tables and the reward-weight sweep as CSV and
Markdown into outputs/tables.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import csv

import config
from scripts.results import (TABLE5, TABLE6, TABLE7, TABLE8, TABLE9,
                             TABLE10, TABLE11, REWARD_SWEEP)


TABLES_DIR = config.TABLES_DIR


def fmt_num(x, nd=2):
    return "-" if x is None else f"{x:.{nd}f}"


def fmt_ci(mean_sd_ci):
    if len(mean_sd_ci) == 4:
        m, s, lo, hi = mean_sd_ci
        return f"{m:.2f} \u00b1 {s:.2f} [{lo:.2f}, {hi:.2f}]"
    else:
        m, s = mean_sd_ci
        return f"{m:.2f} \u00b1 {s:.2f}"


def write_csv(rows, path, header):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        for r in rows:
            w.writerow(r)


def write_md(rows, path, header, title=None):
    lines = []
    if title:
        lines.append(f"# {title}\n")
    lines.append("| " + " | ".join(header) + " |")
    lines.append("|" + "|".join("---" for _ in header) + "|")
    for r in rows:
        lines.append("| " + " | ".join(str(x) for x in r) + " |")
    Path(path).write_text("\n".join(lines), encoding="utf-8")


def build_table5():
    header = ["Measure"] + TABLE5["columns"]
    rows = []
    for measure, vals in TABLE5["rows"]:
        row = [measure] + [fmt_num(v, 3) if isinstance(v, float) else fmt_num(v, 1)
                           for v in vals]
        rows.append(row)
    write_csv(rows, TABLES_DIR / "table05_simulator_fidelity.csv", header)
    write_md(rows, TABLES_DIR / "table05_simulator_fidelity.md", header,
             title="Table 5. Simulator and state-estimator fidelity on held-out test learners")
    print(f"  Table 5 -> {TABLES_DIR / 'table05_simulator_fidelity.csv'}")


def build_table6():
    header = ["Category", "Method",
              "RA (%) mean \u00b1 SD [95% CI]",
              "NLG (%) mean \u00b1 SD [95% CI]",
              "PVR (%) mean \u00b1 SD",
              "ACR mean \u00b1 SD",
              "CLMR (%) mean \u00b1 SD",
              "CE (episodes) mean \u00b1 SD"]
    rows = []
    for entry in TABLE6:
        cat, method, ra, nlg, pvr, acr, clmr, ce = entry
        row = [cat, method,
               fmt_ci(ra),
               fmt_ci(nlg),
               f"{pvr[0]:.2f} \u00b1 {pvr[1]:.2f}",
               f"{acr[0]:.1f} \u00b1 {acr[1]:.1f}",
               f"{clmr[0]:.2f} \u00b1 {clmr[1]:.2f}",
               f"{ce[0]} \u00b1 {ce[1]}" if ce else "n/a"]
        rows.append(row)
    write_csv(rows, TABLES_DIR / "table06_overall_performance.csv", header)
    write_md(rows, TABLES_DIR / "table06_overall_performance.md", header,
             title="Table 6. Performance on out-of-fold test learners")
    print(f"  Table 6 -> {TABLES_DIR / 'table06_overall_performance.csv'}")


def build_table7():
    header = ["Block", "Configuration",
              "RA (%)", "NLG (%)", "PVR (%)", "ACR", "CLMR (%)", "CE"]
    rows = []
    for entry in TABLE7:
        block, cfg, ra, nlg, pvr, acr, clmr, ce = entry
        rows.append([block, cfg,
                     f"{ra[0]:.2f} \u00b1 {ra[1]:.2f}",
                     f"{nlg[0]:.2f} \u00b1 {nlg[1]:.2f}",
                     f"{pvr[0]:.2f} \u00b1 {pvr[1]:.2f}",
                     f"{acr[0]:.1f} \u00b1 {acr[1]:.1f}",
                     f"{clmr[0]:.2f} \u00b1 {clmr[1]:.2f}",
                     f"{ce[0]} \u00b1 {ce[1]}"])
    write_csv(rows, TABLES_DIR / "table07_ablation.csv", header)
    write_md(rows, TABLES_DIR / "table07_ablation.md", header,
             title="Table 7. Ablation experiment results")
    print(f"  Table 7 -> {TABLES_DIR / 'table07_ablation.csv'}")


def build_table8():
    header = ["Learner group", "Learners (n)",
              "NLG (%)", "Raw gain (points)",
              "Posttest adjusted for pretest",
              "RA (%)", "CLMR (%)",
              "Average recommended path length (steps)",
              "NLG difference from DQN (percentage points, 95% CI)",
              "NLG difference from D3QN+PER (percentage points, 95% CI)"]
    rows = []
    for entry in TABLE8:
        (group, n, nlg, rawg, post, ra, clmr, path, dqn_diff, d3qn_diff) = entry
        rows.append([group, n,
                     f"{nlg[0]:.2f} \u00b1 {nlg[1]:.2f}",
                     f"{rawg[0]:.2f} \u00b1 {rawg[1]:.2f}",
                     f"{post[0]:.2f} \u00b1 {post[1]:.2f}",
                     f"{ra[0]:.2f} \u00b1 {ra[1]:.2f}",
                     f"{clmr[0]:.2f} \u00b1 {clmr[1]:.2f}",
                     f"{path[0]:.1f} \u00b1 {path[1]:.1f}",
                     f"+{dqn_diff[0]:.2f} [{dqn_diff[1]:.2f}, {dqn_diff[2]:.2f}]",
                     f"+{d3qn_diff[0]:.2f} [{d3qn_diff[1]:.2f}, {d3qn_diff[2]:.2f}]"])
    write_csv(rows, TABLES_DIR / "table08_learner_groups.csv", header)
    write_md(rows, TABLES_DIR / "table08_learner_groups.md", header,
             title="Table 8. Performance of ID3QN across learner groups")
    print(f"  Table 8 -> {TABLES_DIR / 'table08_learner_groups.csv'}")


def build_table9():
    header = ["Method", "Parameters", "MACs per decision",
              "Replay storage (MB)", "Training time (min)",
              "Peak GPU memory (GB)", "CPU latency per decision (ms)"]
    rows = []
    for entry in TABLE9:
        method, params, macs, replay, tt, gpu, lat = entry
        rows.append([method, params, macs,
                     "n/a" if replay is None else f"{replay:.2f}",
                     tt,
                     "n/a" if gpu is None else f"{gpu:.2f}",
                     f"{lat:.2f}"])
    write_csv(rows, TABLES_DIR / "table09_computational_cost.csv", header)
    write_md(rows, TABLES_DIR / "table09_computational_cost.md", header,
             title="Table 9. Computational cost of reinforcement-learning methods")
    print(f"  Table 9 -> {TABLES_DIR / 'table09_computational_cost.csv'}")


def build_table10():
    header = ["Setting", "Condition", "RA (%)", "NLG (%)", "PVR (%)"]
    rows = []
    for setting, cond, ra, nlg, pvr in TABLE10:
        rows.append([setting, cond,
                     f"{ra[0]:.2f} \u00b1 {ra[1]:.2f}",
                     f"{nlg[0]:.2f} \u00b1 {nlg[1]:.2f}",
                     f"{pvr[0]:.2f} \u00b1 {pvr[1]:.2f}"])
    write_csv(rows, TABLES_DIR / "table10_cold_start_temporal_external.csv", header)
    write_md(rows, TABLES_DIR / "table10_cold_start_temporal_external.md",
             header,
             title="Table 10. Cold start, temporal generalisation and external validation")
    print(f"  Table 10 -> {TABLES_DIR / 'table10_cold_start_temporal_external.csv'}")


def build_table11():
    header = ["Method", "Overestimation control",
              "State value separation", "Prioritized sampling",
              "Valid action handling", "Training data",
              "RA difference from DQN (percentage points, relative %)",
              "Main limitation"]
    write_csv(TABLE11, TABLES_DIR / "table11_comparison.csv", header)
    write_md(TABLE11, TABLES_DIR / "table11_comparison.md", header,
             title="Table 11. Comparison of core characteristics and performance")
    print(f"  Table 11 -> {TABLES_DIR / 'table11_comparison.csv'}")


def build_reward_sweep():
    header = ["lambda_1", "lambda_2", "lambda_3",
              "Val RA (%)", "Val NLG (%)", "Val CLMR (%)",
              "Standardised composite score"]
    rows = []
    for l1, l2, l3, ra, nlg, clmr, score in REWARD_SWEEP:
        rows.append([f"{l1:.1f}", f"{l2:.1f}", f"{l3:.1f}",
                     f"{ra:.2f}", f"{nlg:.2f}", f"{clmr:.2f}",
                     f"{score:+.3f}"])
    write_csv(rows, TABLES_DIR / "tableS14_reward_sweep.csv", header)
    write_md(rows, TABLES_DIR / "tableS14_reward_sweep.md", header,
             title="Table S14. Reward-weight sweep on validation learners")
    print(f"  Table S14 -> {TABLES_DIR / 'tableS14_reward_sweep.csv'}")


def main():
    print("Writing evaluation tables ...")
    build_table5()
    build_table6()
    build_table7()
    build_table8()
    build_table9()
    build_table10()
    build_table11()
    build_reward_sweep()
    print("Done.")


if __name__ == "__main__":
    main()
