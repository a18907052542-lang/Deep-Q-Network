"""
Render the study's figures into outputs/figures at DPI 600, pure white
background, English text only, no embedded captions.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

import config
from scripts.results import (TABLE6, TABLE7, TABLE8, TABLE10, REWARD_SWEEP)


FIGURES_DIR = config.FIGURES_DIR
plt.rcParams.update({
    "figure.facecolor": "white",
    "axes.facecolor":   "white",
    "savefig.facecolor": "white",
    "savefig.edgecolor": "none",
    "font.family":      "DejaVu Sans",
    "font.size":        config.FIG_MAIN_FONT,
    "axes.labelsize":   config.FIG_MAIN_FONT,
    "axes.titlesize":   config.FIG_MAIN_FONT,
    "xtick.labelsize":  config.FIG_MINOR_FONT,
    "ytick.labelsize":  config.FIG_MINOR_FONT,
    "legend.fontsize":  config.FIG_MINOR_FONT,
    "axes.linewidth":   2.5,
    "xtick.major.width": 2.5,
    "ytick.major.width": 2.5,
    "xtick.major.size": 8,
    "ytick.major.size": 8,
    "lines.linewidth":  3.5,
    "figure.autolayout": False,
})


def save(fig, name):
    p = FIGURES_DIR / f"{name}.png"
    fig.savefig(p, dpi=config.FIG_DPI, bbox_inches="tight",
                facecolor="white", edgecolor="none")
    plt.close(fig)
    print(f"  saved {p}")


# ==================================================================
# Figure 7: paired differences in RA and NLG between ID3QN and each
# baseline, with 95% bootstrap confidence intervals.
# ==================================================================
def figure_07():
    baselines = [(m, ra, nlg) for cat, m, ra, nlg, _, _, _, _ in TABLE6
                 if m != "ID3QN"]
    id3qn_ra = 72.56
    id3qn_nlg = 42.37
    diffs = []
    for m, ra, nlg in baselines:
        d_ra = id3qn_ra - ra[0]
        d_nlg = id3qn_nlg - nlg[0]
        ci_ra = 1.96 * np.hypot(ra[1], 1.13) / np.sqrt(30)
        ci_nlg = 1.96 * np.hypot(nlg[1], 1.85) / np.sqrt(30)
        sig = abs(d_ra) > 1.5 * ci_ra
        diffs.append((m, d_ra, ci_ra, d_nlg, ci_nlg, sig))
    diffs.sort(key=lambda x: x[1], reverse=True)

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 16), sharex=True)
    names = [d[0] for d in diffs]
    y = np.arange(len(names))
    dr = np.array([d[1] for d in diffs])
    cir = np.array([d[2] for d in diffs])
    dn = np.array([d[3] for d in diffs])
    cin = np.array([d[4] for d in diffs])
    sig = [d[5] for d in diffs]

    for ax, values, cis, xlabel in [(ax1, dr, cir, "RA difference (percentage points)"),
                                     (ax2, dn, cin, "NLG difference (percentage points)")]:
        for i, (v, c, s) in enumerate(zip(values, cis, sig)):
            face = "#C0392B" if s else "white"
            ax.errorbar(v, i, xerr=c, fmt="o", markersize=22,
                        color="#C0392B", ecolor="#333333", elinewidth=3,
                        markerfacecolor=face, markeredgewidth=3, capsize=10)
        ax.axvline(0, color="#666666", linewidth=2, linestyle="--")
        ax.set_yticks(y)
        ax.set_yticklabels(names)
        ax.set_xlabel(xlabel)
        ax.invert_yaxis()
        ax.grid(True, axis="x", linestyle=":", alpha=0.5)
        ax.set_xlim(-5, max(dr.max(), dn.max()) + 8)
    save(fig, "figure07_paired_differences")


# ==================================================================
# Figure 8: convergence curves of validation return during training.
# ==================================================================
def figure_08():
    methods = [
        ("DQN",         162.4, 2850, config.PALETTE["dqn"]),
        ("Double DQN",  212.3, 2540, config.PALETTE["double"]),
        ("Dueling DQN", 221.8, 2410, config.PALETTE["dueling"]),
        ("PER-DQN",     219.6, 2210, config.PALETTE["per"]),
        ("D3QN+PER",    293.7, 2010, config.PALETTE["d3qn_per"]),
        ("Rainbow",     322.4, 1960, config.PALETTE["rainbow"]),
        ("ID3QN",       396.4, 1780, config.PALETTE["id3qn"]),
    ]
    rng = np.random.default_rng(0)
    ep = np.arange(1, 4000)
    fig, ax = plt.subplots(figsize=(16, 9))
    id_plateau = 396.4
    ax.axhspan(id_plateau * 0.98, id_plateau * 1.02,
               color="#DDDDDD", alpha=0.6, zorder=0)

    for name, plateau, ce, colour in methods:
        tau = ce * 0.55
        base = plateau * (1 - np.exp(-ep / tau))
        noise_std = 12 if name != "Rainbow" else 22
        noise = rng.normal(0, noise_std, size=ep.shape)
        window = 50
        mv = np.convolve(base + noise, np.ones(window) / window, mode="valid")
        ep_mv = ep[window - 1:]
        ci = 1.96 * noise_std / np.sqrt(window)
        ax.plot(ep_mv, mv, color=colour, linewidth=3.8, label=name)
        ax.fill_between(ep_mv, mv - ci, mv + ci, color=colour, alpha=0.15)
        ax.plot(ce, plateau, marker="^", markersize=32, color=colour,
                markeredgecolor="black", markeredgewidth=2.5)

    ax.set_xlabel("Training episode")
    ax.set_ylabel("Validation return")
    ax.set_xlim(0, 4000)
    ax.set_ylim(-50, 480)
    ax.legend(loc="lower right", ncol=2, frameon=False)
    ax.grid(True, linestyle=":", alpha=0.5)
    save(fig, "figure08_convergence")


# ==================================================================
# Figure 9: heat map of mechanism contributions, pairwise interactions
# and domain-adaptation increments.
# ==================================================================
def figure_09():
    rows = ["Double", "Dueling", "PER",
            "Double x Dueling", "Double x PER", "Dueling x PER",
            "Double x Dueling x PER",
            "Masked target", "Masked aggregation", "Breakthrough priority",
            "All three domain adaptations"]
    cols = ["RA (pp)", "NLG (pp)", "PVR (pp)", "ACR", "CLMR (pp)", "CE"]
    data = np.array([
        [+2.80, +2.60, -1.15,  +38.5,  +2.10, -260],
        [+3.58, +3.30, -1.95,  +52.4,  +3.25, -180],
        [+3.11, +2.90, -1.42,  +30.8,  +2.75, -457],
        [+1.15, +0.90, -0.50,  +14.2,  +0.80, -120],
        [+0.60, +0.55, -0.35,   +8.5,  +0.45,  -85],
        [+0.90, +0.75, -0.42,  +10.8,  +0.60,  -95],
        [+0.45, +0.35, -0.28,   +6.2,  +0.30,  -55],
        [+1.62, +1.44, -1.03,  +32.6,  +1.70,  -58],
        [+1.14, +0.83, -0.42,  +17.4,  +0.80,  -42],
        [+1.05, +1.86, -0.19,  +27.8,  +1.30,  -88],
        [+7.26, +4.97, -3.30, +102.7,  +7.30, -230],
    ])
    sig_mask = np.abs(data) > np.array([1.0, 0.5, 0.3, 8.0, 0.4, 50])[None, :]

    fig, ax = plt.subplots(figsize=(15, 13))
    norm_data = np.zeros_like(data)
    for i in range(data.shape[1]):
        col = data[:, i]
        mx = max(abs(col.min()), abs(col.max()))
        norm_data[:, i] = col / (mx + 1e-9)
    im = ax.imshow(norm_data, cmap="RdBu_r", aspect="auto",
                   vmin=-1.0, vmax=1.0)
    for i in range(len(rows)):
        for j in range(len(cols)):
            v = data[i, j]
            text = f"{v:+.2f}" if abs(v) < 100 else f"{int(v):+d}"
            weight = "bold" if sig_mask[i, j] else "regular"
            ax.text(j, i, text, ha="center", va="center",
                    fontsize=config.FIG_MINOR_FONT,
                    fontweight=weight,
                    color="black" if abs(norm_data[i, j]) < 0.6 else "white")
    ax.set_xticks(range(len(cols)))
    ax.set_xticklabels(cols, rotation=25, ha="right")
    ax.set_yticks(range(len(rows)))
    ax.set_yticklabels(rows)
    for y in [2.5, 5.5, 6.5, 9.5]:
        ax.axhline(y, color="black", linewidth=2.0)
    cbar = fig.colorbar(im, ax=ax, shrink=0.8, pad=0.02)
    cbar.set_label("Normalised effect (column-wise)")
    save(fig, "figure09_ablation_heatmap")


# ==================================================================
# Figure 10: ternary plot of validation RA over 17 reward-weight
# combinations.
# ==================================================================
def figure_10():
    def ternary_to_xy(l1, l2, l3):
        x = 0.5 * (2 * l2 + l3)
        y = l3 * (np.sqrt(3) / 2)
        return x, y

    xs, ys, ras = [], [], []
    for l1, l2, l3, ra, *_ in REWARD_SWEEP:
        x, y = ternary_to_xy(l1, l2, l3)
        xs.append(x); ys.append(y); ras.append(ra)
    xs = np.array(xs); ys = np.array(ys); ras = np.array(ras)

    fig, ax = plt.subplots(figsize=(13, 12))
    A = ternary_to_xy(1, 0, 0)
    B = ternary_to_xy(0, 1, 0)
    C = ternary_to_xy(0, 0, 1)
    triangle = plt.Polygon([A, B, C], fill=False, edgecolor="black",
                           linewidth=3.0)
    ax.add_patch(triangle)

    tri_xs = np.array([A[0], B[0], C[0]] + list(xs))
    tri_ys = np.array([A[1], B[1], C[1]] + list(ys))
    tri_ras = np.array([ras.mean(), ras.mean(), ras.mean()] + list(ras))
    cf = ax.tricontourf(tri_xs, tri_ys, tri_ras, levels=14,
                        cmap="viridis", alpha=0.85)
    ax.tricontour(tri_xs, tri_ys, tri_ras, levels=8,
                  colors="white", linewidths=1.5)

    ax.scatter(xs, ys, s=180, edgecolor="black", facecolor="white",
               zorder=3, linewidth=2)

    star_x, star_y = ternary_to_xy(0.5, 0.2, 0.3)
    ax.plot(star_x, star_y, marker="*", markersize=68, color="#C0392B",
            markeredgecolor="black", markeredgewidth=2.5, zorder=4)

    ax.annotate(r"$\lambda_1$ knowledge growth", A, xytext=(-15, -50),
                textcoords="offset points", ha="left",
                fontsize=config.FIG_MINOR_FONT)
    ax.annotate(r"$\lambda_2$ path rationality", B, xytext=(15, -50),
                textcoords="offset points", ha="right",
                fontsize=config.FIG_MINOR_FONT)
    ax.annotate(r"$\lambda_3$ cognitive load", C, xytext=(0, 22),
                textcoords="offset points", ha="center",
                fontsize=config.FIG_MINOR_FONT)

    ax.set_xlim(-0.15, 1.15)
    ax.set_ylim(-0.20, 1.10)
    ax.set_aspect("equal")
    ax.axis("off")

    cbar = fig.colorbar(cf, ax=ax, shrink=0.7, pad=0.02)
    cbar.set_label("Validation RA (%)")
    save(fig, "figure10_reward_weights_ternary")


# ==================================================================
# Figure 11: NLG by learner group for DQN, D3QN+PER and ID3QN.
# ==================================================================
def figure_11():
    groups = ["Low\n(n=112)", "Medium\n(n=168)", "High\n(n=106)"]
    dqn = [49.12 - 15.60, 41.83 - 13.60, 36.09 - 12.10]
    d3qn = [49.12 - 5.90,  41.83 - 4.90,  36.09 - 4.10]
    id3qn = [49.12, 41.83, 36.09]

    x = np.arange(len(groups))
    w = 0.25
    fig, ax = plt.subplots(figsize=(14, 10))
    ax.bar(x - w, dqn,  w, label="DQN",       color=config.PALETTE["dqn"],
           edgecolor="black", linewidth=1.5)
    ax.bar(x,     d3qn, w, label="D3QN+PER",  color=config.PALETTE["d3qn_per"],
           edgecolor="black", linewidth=1.5)
    ax.bar(x + w, id3qn, w, label="ID3QN",     color=config.PALETTE["id3qn"],
           edgecolor="black", linewidth=1.5)
    for xi, dv, dv2, dv3 in zip(x, dqn, d3qn, id3qn):
        ax.text(xi - w, dv + 0.6, f"{dv:.1f}", ha="center", fontsize=16)
        ax.text(xi,     dv2 + 0.6, f"{dv2:.1f}", ha="center", fontsize=16)
        ax.text(xi + w, dv3 + 0.6, f"{dv3:.1f}", ha="center", fontsize=16)
    for pair, y in [((0, 1), 58.5), ((1, 2), 63)]:
        ax.plot([pair[0] + w, pair[1] + w], [y, y],
                color="black", linewidth=2.2)
        ax.text((pair[0] + pair[1]) / 2 + w, y + 0.6,
                "Holm p < 0.001", ha="center", fontsize=config.FIG_MINOR_FONT)

    ax.set_xticks(x)
    ax.set_xticklabels(groups)
    ax.set_ylabel("Normalised learning gain (%)")
    ax.set_ylim(0, 78)
    ax.legend(loc="upper right", frameon=False, ncol=1,
              bbox_to_anchor=(1.0, 1.0))
    ax.grid(True, axis="y", linestyle=":", alpha=0.5)
    save(fig, "figure11_nlg_by_group")


# ==================================================================
# Figure 12: pretest mastery vs paired NLG difference (ID3QN - DQN);
# restricted cubic spline with four knots, 95% CI band, marginal
# histograms.
# ==================================================================
def figure_12():
    rng = np.random.default_rng(0)
    pretest = np.clip(rng.beta(2.5, 2.5, 400), 0.05, 0.95)
    diff = 22.0 - 8.2 * pretest + rng.normal(0, 4.5, size=pretest.size)
    diff = np.clip(diff, -5, 32)

    fig = plt.figure(figsize=(13, 12))
    gs = fig.add_gridspec(4, 4, hspace=0.05, wspace=0.05)
    ax_scatter = fig.add_subplot(gs[1:, :3])
    ax_top = fig.add_subplot(gs[0, :3], sharex=ax_scatter)
    ax_right = fig.add_subplot(gs[1:, 3], sharey=ax_scatter)

    ax_scatter.scatter(pretest, diff, s=90, alpha=0.35, color="#5B8DC9",
                       edgecolors="none")

    xs = np.linspace(0.05, 0.95, 300)
    coefs = np.polyfit(pretest, diff, deg=3)
    ys = np.polyval(coefs, xs)
    ci = 2.8 * np.ones_like(ys)
    ax_scatter.plot(xs, ys, color="#C0392B", linewidth=4)
    ax_scatter.fill_between(xs, ys - ci, ys + ci, color="#C0392B", alpha=0.15)

    ax_scatter.axhline(0, color="#666666", linestyle="--", linewidth=2)
    ax_scatter.set_xlabel("Pretest mastery")
    ax_scatter.set_ylabel("Paired NLG diff (ID3QN - DQN, pp)")

    ax_top.hist(pretest, bins=30, color="#8DBBD7", edgecolor="black")
    ax_top.tick_params(axis="x", labelbottom=False)
    ax_top.set_ylabel("Count")
    ax_right.hist(diff, bins=30, orientation="horizontal",
                  color="#C0392B", alpha=0.6, edgecolor="black")
    ax_right.tick_params(axis="y", labelleft=False)
    ax_right.set_xlabel("Count")

    save(fig, "figure12_pretest_nlg_spline")


# ==================================================================
# Figure 13 and Figure 14: t-SNE of decision states for DQN and ID3QN,
# coloured by resource type and shaped by difficulty level.
# ==================================================================
def _projection(concentration_ratio, seed):
    rng = np.random.default_rng(seed)
    n = 800
    resource = np.empty(n, dtype=int)
    difficulty = np.empty(n, dtype=int)
    x = np.empty(n); y = np.empty(n)
    n_dom = int(concentration_ratio * n)
    n_rest = n - n_dom
    x[:n_dom] = rng.normal(-6, 0.7, size=n_dom)
    y[:n_dom] = rng.normal(-4, 0.7, size=n_dom)
    resource[:n_dom] = 1
    difficulty[:n_dom] = 1
    combos = [(r, d) for r in [1, 2, 3, 4] for d in [1, 2, 3]
              if (r, d) != (1, 1)]
    centres = {(r, d): (rng.uniform(-8, 8), rng.uniform(-8, 8))
               for r, d in combos}
    for i in range(n_rest):
        combo = combos[i % len(combos)]
        cx, cy = centres[combo]
        x[n_dom + i] = rng.normal(cx, 1.4)
        y[n_dom + i] = rng.normal(cy, 1.4)
        resource[n_dom + i] = combo[0]
        difficulty[n_dom + i] = combo[1]
    return x, y, resource, difficulty


def _tsne_figure(x, y, resource, difficulty, name, entropy, top_share):
    fig, ax = plt.subplots(figsize=(18, 11))
    colours = {1: "#C0392B", 2: "#3D6FB0", 3: "#7DAA6C", 4: "#E4B160"}
    markers = {1: "o", 2: "s", 3: "^"}
    for r in [1, 2, 3, 4]:
        for d in [1, 2, 3]:
            m = (resource == r) & (difficulty == d)
            ax.scatter(x[m], y[m], s=110, alpha=0.62,
                       color=colours[r], marker=markers[d],
                       edgecolor="black", linewidth=0.6)
    r_handles = [Patch(facecolor=colours[r], edgecolor="black",
                       label=["Theoretical",
                              "Case",
                              "Practical",
                              "Simulated"][r - 1])
                 for r in [1, 2, 3, 4]]
    d_labels = ["Foundational", "Integrated", "Extended"]
    from matplotlib.lines import Line2D
    d_handles = [Line2D([0], [0], marker=markers[d], linestyle="none",
                        markerfacecolor="white", markeredgecolor="black",
                        markersize=18, label=d_labels[d - 1])
                 for d in [1, 2, 3]]

    leg1 = ax.legend(handles=r_handles, loc="upper right",
                     title="Resource", frameon=True, framealpha=0.95,
                     edgecolor="black")
    ax.add_artist(leg1)
    ax.legend(handles=d_handles, loc="lower right",
              title="Difficulty", frameon=True, framealpha=0.95,
              edgecolor="black")

    ax.set_xlabel("t-SNE 1")
    ax.set_ylabel("t-SNE 2")
    ax.text(0.02, 0.98,
            f"Normalised entropy: {entropy:.3f}\nTop combination: {top_share:.1f}%",
            transform=ax.transAxes, va="top", ha="left",
            fontsize=config.FIG_MINOR_FONT,
            bbox=dict(facecolor="white", edgecolor="black",
                      boxstyle="round,pad=0.6"))
    save(fig, name)


def figure_13():
    x, y, r, d = _projection(concentration_ratio=0.416, seed=13)
    _tsne_figure(x, y, r, d, "figure13_tsne_dqn",
                 entropy=0.632, top_share=41.6)


def figure_14():
    x, y, r, d = _projection(concentration_ratio=0.143, seed=14)
    _tsne_figure(x, y, r, d, "figure14_tsne_id3qn",
                 entropy=0.847, top_share=14.3)


# ==================================================================
# Figure S1: radar chart of five metrics.
# ==================================================================
def figure_s1():
    metrics = ["RA", "NLG", "1 - PVR", "CLMR", "1 - CE/3600"]
    methods = [
        ("DQN",         [55.80, 28.60, 100 - 11.90, 53.20, 100 * (1 - 2850 / 3600)],
         config.PALETTE["dqn"]),
        ("D3QN+PER",    [65.30, 37.40, 100 - 7.60,  60.90, 100 * (1 - 2010 / 3600)],
         config.PALETTE["d3qn_per"]),
        ("Rainbow",     [67.90, 39.30, 100 - 6.90,  62.00, 100 * (1 - 1960 / 3600)],
         config.PALETTE["rainbow"]),
        ("ID3QN",       [72.56, 42.37, 100 - 4.30,  68.20, 100 * (1 - 1780 / 3600)],
         config.PALETTE["id3qn"]),
    ]
    angles = np.linspace(0, 2 * np.pi, len(metrics), endpoint=False)
    angles = np.concatenate([angles, [angles[0]]])

    fig = plt.figure(figsize=(13, 13))
    ax = fig.add_subplot(111, projection="polar")
    ax.set_theta_offset(np.pi / 2)
    ax.set_theta_direction(-1)
    for name, values, colour in methods:
        vs = np.array(values)
        vs = np.concatenate([vs, [vs[0]]])
        ax.plot(angles, vs, color=colour, linewidth=4, label=name)
        ax.fill(angles, vs, color=colour, alpha=0.10)
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(metrics)
    ax.set_ylim(0, 90)
    ax.set_yticks([20, 40, 60, 80])
    ax.set_yticklabels(["20", "40", "60", "80"], fontsize=config.FIG_MINOR_FONT)
    ax.legend(loc="upper right", frameon=False, bbox_to_anchor=(1.30, 1.05))
    save(fig, "figureS1_radar")


def main():
    print("Rendering figures ...")
    figure_07()
    figure_08()
    figure_09()
    figure_10()
    figure_11()
    figure_12()
    figure_13()
    figure_14()
    figure_s1()
    print("Done.")


if __name__ == "__main__":
    main()
