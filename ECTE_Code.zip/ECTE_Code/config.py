"""
Central configuration for the ECTE adaptive tutoring experiment. Every
constant fixes a hyperparameter of the MDP, the ID3QN training loop or
the rendering pipeline.
"""

from pathlib import Path

# ------------------------------------------------------------------
# Paths
# ------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent
DATASET_DIR = PROJECT_ROOT / "dataset"
OUTPUT_DIR = PROJECT_ROOT / "outputs"
TABLES_DIR = OUTPUT_DIR / "tables"
FIGURES_DIR = OUTPUT_DIR / "figures"
LOGS_DIR = OUTPUT_DIR / "logs"
for d in [OUTPUT_DIR, TABLES_DIR, FIGURES_DIR, LOGS_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# ------------------------------------------------------------------
# MDP settings (section 3.2)
# ------------------------------------------------------------------
N_KP = 68
N_DIFFICULTY = 3
N_RESOURCE = 4
N_ACTIONS = N_KP * N_DIFFICULTY * N_RESOURCE   # 816
STATE_DIM = N_KP + 11 + 1                       # 80 = k(68) + p(11) + c(1)
T_MAX = 40
K_MAS = 0.80                                    # mastery threshold
K_PRE = 0.60                                    # prerequisite threshold
N_MIN = 20                                      # log-support threshold for the mask

# ------------------------------------------------------------------
# ID3QN and network hyperparameters (Table S8)
# ------------------------------------------------------------------
HIDDEN = [256, 128, 64]
LEARNING_RATE = 5e-4
DISCOUNT = 0.95                                 # gamma
REPLAY_CAPACITY = 50000                         # C
MINIBATCH = 64                                  # B
LEARNING_START = 5000                           # first update
SOFT_UPDATE_TAU = 0.005
PER_ALPHA = 0.6
PER_BETA_START = 0.4
PER_BETA_END = 1.0
PER_EPSILON = 1e-6
BREAKTHROUGH_KAPPA = 1.0
EPS_START = 1.0
EPS_END = 0.05
EPS_DECAY_EPISODES = 1500
GRAD_CLIP = 10.0
TOTAL_EPISODES = 6000
HUBER_THRESHOLD = 1.0

# ------------------------------------------------------------------
# Reward weights selected on validation learners (section 4.7)
# ------------------------------------------------------------------
LAMBDA_1 = 0.5                                  # knowledge growth
LAMBDA_2 = 0.2                                  # path rationality
LAMBDA_3 = 0.3                                  # cognitive load
DELTA_MAX = 0.25
DELTA_C = 0.30
STEP_COST_NU = 0.05
C_L, C_U = 0.30, 0.70                           # moderate cognitive-load range

# ------------------------------------------------------------------
# State update
# ------------------------------------------------------------------
PREF_SMOOTHING_ETA = 0.10
COG_WINDOW = 5
DEFAULT_GUESS = 0.20
DEFAULT_SLIP = 0.15

# ------------------------------------------------------------------
# DKT training simulator and CAKT evaluation simulator
# ------------------------------------------------------------------
DKT_HIDDEN = 128
DKT_EPOCHS = 20
DKT_LR = 1e-3
DKT_BATCH = 32
CAKT_HEADS = 4
CAKT_HIDDEN = 128

# ------------------------------------------------------------------
# Cross validation
# ------------------------------------------------------------------
N_FOLDS = 5
SEEDS = [0, 1, 2, 3, 4]

# ------------------------------------------------------------------
# Rendering settings for figures
# ------------------------------------------------------------------
FIG_DPI = 600
FIG_MAIN_FONT = 26
FIG_MINOR_FONT = 18
FIG_BG = "white"
PALETTE = {
    "dqn": "#5B8DC9", "double": "#3D6FB0", "dueling": "#8DBBD7",
    "per": "#2A4C7A", "d3qn_per": "#4A7BC0", "rainbow": "#9E7ABF",
    "id3qn": "#C0392B", "cseal": "#7DAA6C", "rl_dkt": "#5C8B4E",
    "cql": "#E4B160", "bcq": "#D19A45", "doubly": "#F0C674",
    "q_learning": "#8FA8AA", "kt_greedy": "#B5B39F", "sasrec": "#A4A48A",
    "syllabus": "#C4C4C4", "random": "#999999",
}
