# Table 10. Cold start, temporal generalisation and external validation

| Setting | Condition | RA (%) | NLG (%) | PVR (%) |
|---|---|---|---|---|
| Cold start | No prior activities | 66.80 ± 1.70 | 34.60 ± 2.30 | 7.40 ± 0.80 |
| Cold start | 5 prior activities | 69.40 ± 1.50 | 38.20 ± 2.10 | 5.60 ± 0.70 |
| Cold start | 10 prior activities | 71.30 ± 1.40 | 40.60 ± 1.90 | 4.90 ± 0.70 |
| Cold start | 20 prior activities | 72.20 ± 1.20 | 42.00 ± 1.90 | 4.40 ± 0.60 |
| Temporal | 2022 to 2023, no retraining | 67.40 ± 1.60 | 36.90 ± 2.20 | 5.80 ± 0.70 |
| Temporal | 2022 and 2023 to 2024, no retraining | 66.10 ± 1.70 | 35.40 ± 2.40 | 6.20 ± 0.80 |
| Temporal | 2022 and 2023 to 2024, retrained each semester | 71.50 ± 1.30 | 41.60 ± 2.00 | 4.60 ± 0.60 |
| External | Junyi Academy, ID3QN | 62.40 ± 1.40 | 34.20 ± 2.10 | 5.60 ± 0.60 |
| External | Junyi Academy, D3QN+PER | 57.80 ± 1.60 | 30.70 ± 2.30 | 7.10 ± 0.70 |
| External | Junyi Academy, CSEAL | 55.30 ± 1.50 | 28.90 ± 2.40 | 7.40 ± 0.70 |
| External | Junyi Academy, KT-greedy | 52.10 ± 1.70 | 26.30 ± 2.50 | 7.90 ± 0.80 |