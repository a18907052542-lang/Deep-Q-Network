# Table 7. Ablation experiment results

| Block | Configuration | RA (%) | NLG (%) | PVR (%) | ACR | CLMR (%) | CE |
|---|---|---|---|---|---|---|---|
| Mechanism factorial | DQN | 55.80 ± 2.34 | 28.60 ± 3.61 | 11.90 ± 1.70 | 162.4 ± 11.6 | 53.20 ± 4.17 | 2850 ± 178 |
| Mechanism factorial | +Double (Double DQN) | 60.24 ± 1.90 | 31.80 ± 3.10 | 9.70 ± 1.10 | 212.3 ± 10.8 | 55.10 ± 3.60 | 2540 ± 156 |
| Mechanism factorial | +Dueling (Dueling DQN) | 61.02 ± 1.80 | 32.50 ± 2.90 | 9.10 ± 1.00 | 221.8 ± 10.1 | 56.70 ± 3.40 | 2410 ± 148 |
| Mechanism factorial | +PER (PER-DQN) | 60.55 ± 1.90 | 32.10 ± 2.90 | 9.90 ± 1.10 | 219.6 ± 9.9 | 56.10 ± 3.40 | 2210 ± 132 |
| Mechanism factorial | +Double +Dueling | 64.48 ± 1.62 | 35.34 ± 2.71 | 8.43 ± 0.98 | 260.4 ± 11.2 | 57.84 ± 3.05 | 2210 ± 139 |
| Mechanism factorial | +Double +PER | 64.01 ± 1.71 | 34.94 ± 2.66 | 8.86 ± 1.02 | 258.2 ± 10.6 | 57.24 ± 2.92 | 2010 ± 127 |
| Mechanism factorial | +Dueling +PER | 64.79 ± 1.58 | 35.64 ± 2.58 | 8.31 ± 0.95 | 273.0 ± 11.4 | 59.64 ± 2.84 | 1880 ± 124 |
| Mechanism factorial | +Double +Dueling +PER (D3QN+PER) | 65.30 ± 1.40 | 37.40 ± 2.40 | 7.60 ± 0.90 | 293.7 ± 12.3 | 60.90 ± 2.50 | 2010 ± 118 |
| Domain adaptation | D3QN+PER +masked target | 66.92 ± 1.31 | 38.84 ± 2.22 | 6.57 ± 0.84 | 326.3 ± 11.0 | 62.60 ± 2.63 | 1952 ± 112 |
| Domain adaptation | D3QN+PER +masked aggregation | 66.44 ± 1.36 | 38.23 ± 2.30 | 7.18 ± 0.87 | 311.1 ± 11.7 | 61.70 ± 2.71 | 1968 ± 115 |
| Domain adaptation | D3QN+PER +both masks | 67.70 ± 1.24 | 39.67 ± 2.08 | 6.15 ± 0.79 | 343.7 ± 10.4 | 63.40 ± 2.58 | 1910 ± 108 |
| Domain adaptation | D3QN+PER +breakthrough aware priority | 66.35 ± 1.33 | 39.26 ± 2.19 | 7.41 ± 0.86 | 321.5 ± 11.3 | 62.20 ± 2.66 | 1922 ± 104 |
| Domain adaptation | D3QN+PER +both masks +breakthrough (ID3QN) | 72.56 ± 1.13 | 42.37 ± 1.85 | 4.30 ± 0.63 | 396.4 ± 9.2 | 68.20 ± 2.44 | 1780 ± 96 |
| State and reward components | ID3QN -support condition of the mask | 70.69 ± 1.21 | 41.74 ± 1.97 | 7.92 ± 0.95 | 380.3 ± 10.1 | 67.92 ± 2.52 | 1838 ± 103 |
| State and reward components | ID3QN -preference vector p_t | 70.45 ± 1.25 | 41.43 ± 2.04 | 4.36 ± 0.66 | 384.0 ± 9.8 | 68.09 ± 2.49 | 1822 ± 101 |
| State and reward components | ID3QN -cognitive load c_t | 71.74 ± 1.18 | 41.86 ± 1.93 | 4.39 ± 0.68 | 382.8 ± 9.6 | 64.58 ± 2.77 | 1814 ± 99 |
| State and reward components | ID3QN -R_path | 71.20 ± 1.22 | 41.65 ± 1.99 | 6.45 ± 0.84 | 378.0 ± 10.3 | 67.96 ± 2.55 | 1846 ± 105 |
| State and reward components | ID3QN -R_cog | 71.88 ± 1.16 | 41.81 ± 1.95 | 4.45 ± 0.70 | 386.6 ± 9.5 | 65.86 ± 2.71 | 1832 ± 100 |