# Table 9. Computational cost of reinforcement-learning methods

| Method | Parameters | MACs per decision | Replay storage (MB) | Training time (min) | Peak GPU memory (GB) | CPU latency per decision (ms) |
|---|---|---|---|---|---|---|
| Q-learning (aggregated states) | 816K | 80K | n/a | 52 | n/a | 0.42 |
| DQN | 114,928 | 113,664 | 32.45 | 118 | 1.62 | 1.32 |
| Double DQN | 114,928 | 113,664 | 32.45 | 124 | 1.62 | 1.36 |
| Dueling DQN | 123,249 | 121,920 | 32.45 | 126 | 1.68 | 1.41 |
| PER-DQN | 114,928 | 113,664 | 33.25 | 132 | 1.66 | 1.35 |
| D3QN+PER | 123,249 | 121,920 | 33.25 | 136 | 1.72 | 1.44 |
| Rainbow | 5,503,366 | 2,736,320 | 33.25 | 248 | 3.94 | 4.18 |
| CQL | 114,928 | 113,664 | 98.60 | 94 | 1.58 | 1.32 |
| BCQ | 229,856 | 227,328 | 98.60 | 112 | 1.74 | 2.68 |
| ID3QN | 123,249 | 121,920 | 38.40 | 142 | 1.76 | 1.52 |