# Table 8. Performance of ID3QN across learner groups

| Learner group | Learners (n) | NLG (%) | Raw gain (points) | Posttest adjusted for pretest | RA (%) | CLMR (%) | Average recommended path length (steps) | NLG difference from DQN (percentage points, 95% CI) | NLG difference from D3QN+PER (percentage points, 95% CI) |
|---|---|---|---|---|---|---|---|---|---|
| Low baseline mastery | 112 | 49.12 ± 2.34 | 34.59 ± 2.21 | 77.18 ± 1.52 | 71.52 ± 1.27 | 69.02 ± 2.42 | 27.6 ± 2.1 | +15.60 [14.20, 16.98] | +5.90 [4.15, 7.66] |
| Medium baseline mastery | 168 | 41.83 ± 2.02 | 20.44 ± 1.46 | 71.38 ± 1.41 | 72.27 ± 1.21 | 68.51 ± 2.55 | 22.8 ± 1.7 | +13.60 [12.45, 14.71] | +4.90 [3.53, 6.25] |
| High baseline mastery | 106 | 36.09 ± 2.17 | 9.84 ± 0.93 | 68.96 ± 1.33 | 74.12 ± 1.12 | 66.87 ± 2.71 | 15.4 ± 1.4 | +12.10 [10.62, 13.64] | +4.10 [2.51, 5.75] |