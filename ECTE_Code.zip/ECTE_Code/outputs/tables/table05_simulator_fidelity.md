# Table 5. Simulator and state-estimator fidelity on held-out test learners

| Measure | Training simulator (DKT) | Evaluation simulator (AKT) | Agent state estimator (BKT) |
|---|---|---|---|
| Next response AUC | 0.842 | 0.867 | 0.824 |
| Next response accuracy (%) | 78.600 | 80.300 | 76.900 |
| Next response RMSE | 0.371 | 0.348 | 0.386 |
| Expected calibration error | 0.028 | 0.021 | 0.036 |
| Mean absolute error of log RT | 0.226 | 0.201 | - |
| Kolmogorov-Smirnov of RT | 0.058 | 0.046 | - |
| MAE of stepwise correctness (replay) | 0.043 | 0.034 | - |