# Table 11. Comparison of core characteristics and performance

| Method | Overestimation control | State value separation | Prioritized sampling | Valid action handling | Training data | RA difference from DQN (percentage points, relative %) | Main limitation |
|---|---|---|---|---|---|---|---|
| Q-learning | N | N | N | Decision | Simulator | -12.20 (-21.9%) | State aggregation removes fine differences in mastery |
| DQN | N | N | N | Decision | Simulator | 0 (reference) | Overestimation and slow convergence |
| Double DQN | Y | N | N | Decision | Simulator | +4.44 (+8.0%) | Weak state value assessment |
| Dueling DQN | N | Y | N | Decision | Simulator | +5.22 (+9.4%) | Overestimation persists |
| PER-DQN | N | N | Y | Decision | Simulator | +4.75 (+8.5%) | Overestimation; no state value separation |
| D3QN+PER | Y | Y | Y | Decision | Simulator | +9.50 (+17.0%) | Targets and advantage means include invalid actions |
| Rainbow | Y | Y | Y | Decision | Simulator | +12.10 (+21.7%) | 51 atoms for each of the 816 actions |
| CQL | Conservative penalty | N | N | Decision | Logs | -1.10 (-2.0%) | Restricted to actions supported by the logs |
| ID3QN | Y | Y | Y (breakthrough aware) | Decision, target and aggregation | Simulator | +16.76 (+30.0%) | Depends on simulator fidelity and on the mask |