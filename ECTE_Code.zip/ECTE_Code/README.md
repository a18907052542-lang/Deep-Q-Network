# ECTE Adaptive Tutoring: Reinforcement Learning Code

Python and PyTorch implementation of a knowledge-graph-constrained
double dueling deep Q-network (ID3QN) for adaptive tutoring in early
childhood teacher education. The project trains and evaluates ID3QN
together with the value-based and offline baselines against the ECTE
interaction dataset under a learner-stratified five-fold cross
validation.

## Contents

```
ECTE_Code/
├── config.py                       Hyperparameters
├── requirements.txt                Python dependencies
├── dataset/                        ECTE interaction dataset
├── src/
│   ├── data_loader.py              Load the dataset, build 5-fold CV
│   ├── knowledge_graph.py          68 knowledge points, 153 edges, v_j
│   ├── mask.py                     Validity mask over 816 actions
│   ├── state.py                    Three-component state (mastery,
│   │                               preference, cognitive load)
│   ├── reward.py                   Composite reward
│   ├── knowledge_tracing.py        BKT / DKT / CAKT simulators
│   ├── networks.py                 Q-network, dueling network, Rainbow
│   ├── replay_buffer.py            PER + breakthrough priority
│   ├── environment.py              Tutoring environment
│   ├── metrics.py                  RA, NLG, PVR, ACR, CLMR, CE
│   ├── train.py                    Training loop
│   ├── evaluate.py                 Greedy policy evaluation
│   └── agents/
│       ├── base.py                 Shared value-agent template
│       ├── dqn_family.py           DQN, Double DQN, Dueling DQN, PER-DQN,
│       │                           D3QN+PER, ID3QN, Rainbow
│       └── heuristics.py           Random, Syllabus order, KT-greedy,
│                                   SASRec, tabular Q-learning
├── scripts/
│   ├── run_experiment.py           Full 5-fold x 5-seed protocol
│   ├── generate_tables.py          Write tables 5-11 and S14
│   ├── generate_figures.py         Render figures 7-14 and S1
│   └── results.py                  Aggregate results across folds and seeds
├── outputs/
│   ├── tables/                     CSV and Markdown
│   ├── figures/                    PNG at DPI 600
│   └── logs/                       Cross-validation logs
└── run_all.sh                      One-line pipeline entry
```

## Requirements

* Python 3.9 or newer
* PyTorch 1.13 or newer
* pandas, numpy, scipy, scikit-learn, matplotlib, tqdm

Install with

```bash
pip install -r requirements.txt
```

Training uses an NVIDIA GPU with at least 8 GB of memory. All
hyperparameters are defined in `config.py`.

## Method

The tutoring problem is modelled as a Markov decision process with an
80-dimensional state, an 816-dimensional discrete action space and a
composite reward covering knowledge growth, path rationality and
cognitive-load balance. ID3QN extends D3QN+PER with three domain
adaptations:

* the double Q-learning target is restricted to the valid action set of
  the next state,
* the dueling advantage stream is centred over valid actions only,
* the prioritised replay priority receives a multiplicative boost for
  transitions in which mastery crosses the mastery threshold after at
  least two consecutive errors (a "breakthrough").

The training simulator is a deep knowledge-tracing LSTM fitted on the
training learners of each fold. Evaluation uses a separate context-aware
attentive knowledge-tracing simulator fitted on training and validation
learners. The agent's state estimator is a Bayesian knowledge-tracing
model with per-knowledge-point guess and slip parameters.

## Running the pipeline

```bash
bash run_all.sh
```

runs:

1. `scripts/run_experiment.py` – trains seven learning agents (DQN,
   Double DQN, Dueling DQN, PER-DQN, D3QN+PER, Rainbow, ID3QN) across
   5 folds and 5 seeds and evaluates them together with the four
   heuristic baselines. Writes per-fold metrics to
   `outputs/logs/cross_validation_results.json`.
2. `scripts/generate_tables.py` – writes the six evaluation tables and
   the reward-weight sweep to `outputs/tables/`.
3. `scripts/generate_figures.py` – renders the nine figures to
   `outputs/figures/` at 600 DPI.

## Individual runs

Every module is directly executable:

```bash
python -m src.data_loader          # verify dataset load and folds
python -m scripts.generate_tables  # regenerate tables
python -m scripts.generate_figures # regenerate figures
```

## Reproducing the reward-weight selection

The 17 combinations of `(lambda_1, lambda_2, lambda_3)` swept on
validation learners are listed in `scripts/results.py` as
`REWARD_SWEEP`. The composite score in the last column is the mean of
the standardised RA, NLG and CLMR; the combination with the highest
score fixes the runtime values of `LAMBDA_1`, `LAMBDA_2`, `LAMBDA_3`
in `config.py`.

## Citation

If you use this code, please cite the accompanying paper on the deep
Q-network with knowledge graph constraints for adaptive tutoring in
early childhood teacher education.
