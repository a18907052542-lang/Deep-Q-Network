# ECTE Interaction Dataset

Deidentified learner interaction logs and supporting materials from the
online learning platform of the Early Childhood Teacher Education (ECTE)
program at the Faculté des Sciences de l'Éducation, Mohammed V University
in Rabat, Morocco, covering academic years 2022 to 2024.

Every file is UTF-8 encoded English.

## Files

| File | Rows | Description |
| --- | ---: | --- |
| `interactions.csv` | 127,458 | Learner activity log |
| `learners.csv` | 386 | Deidentified learner metadata |
| `knowledge_points.csv` | 68 | Curriculum knowledge points |
| `prerequisites.csv` | 153 | Directed prerequisite edges with strength |
| `items.csv` | 735 | Assessment items |
| `courses.csv` | 4 | Core courses of the ECTE program |
| `annotator_ratings.csv` | 2,472 | Six ECTE faculty annotators over 412 candidate pairs |
| `statistics.json` | 1 | Aggregate statistics of the release |

The dataset covers structured platform logs only. Audio, video, image and
free-text uploads from learners are outside the scope of the release. The
`resource_type` field of `interactions.csv` records the format of the
learning resource that the platform served (video lecture, interactive
task, reading or quiz), not any artefact contributed by the learner.

## Field definitions

### interactions.csv

| Field | Type | Range or values | Description |
| --- | --- | --- | --- |
| `record_id` | string | 16 hex chars | Deidentified record identifier |
| `learner_id` | string | 16 hex chars | Deidentified learner identifier |
| `course_id` | string | C1 to C4 | Course identifier |
| `knowledge_point_id` | int | 1 to 68 | Knowledge point of the item |
| `difficulty_level` | int | 1 to 3 | 1 foundational, 2 intermediate, 3 advanced |
| `resource_type` | int | 1 to 4 | 1 video, 2 interactive task, 3 reading, 4 quiz |
| `item_id` | int | 1 to 735 | Assessment item identifier |
| `response` | int | 0 or 1 | 0 incorrect, 1 correct |
| `response_time_s` | float | 3 to 900 | Time from item onset to submission, in seconds |
| `study_duration_s` | float | 10 to 3600 | Time spent on the recommended activity, in seconds |
| `timestamp` | datetime | 2022-05 to 2024-06 | Wall clock time with per-learner random offset applied |
| `session_id` | string | 16 hex chars | Contiguous activity session, split at gaps longer than 30 min |

### learners.csv

| Field | Type | Description |
| --- | --- | --- |
| `learner_id` | string | Deidentified learner identifier |
| `baseline_mastery` | float | Baseline mastery over the curriculum, from the diagnostic pretest |
| `records` | int | Number of records contributed by the learner |
| `enrolled_courses` | string | Pipe separated list of enrolled courses among C1 to C4 |

### knowledge_points.csv

| Field | Description |
| --- | --- |
| `knowledge_point_id` | Integer identifier 1 to 68 |
| `name` | Human readable name |
| `anchor_course` | Course in which the point is anchored, C1 to C4 |
| `is_foundation` | 1 if the point is one of the 14 foundations shared across all four courses |

### prerequisites.csv

| Field | Description |
| --- | --- |
| `edge_id` | Integer identifier 1 to 153 |
| `from_kp` | Prerequisite knowledge point |
| `to_kp` | Dependent knowledge point |
| `strength` | Normalised strength w in (0, 1] |

### items.csv

| Field | Description |
| --- | --- |
| `item_id` | Integer identifier 1 to 735 |
| `knowledge_point_id` | Knowledge point covered by the item |
| `difficulty_level` | 1 foundational, 2 intermediate, 3 advanced |
| `resource_type` | 1 video, 2 interactive task, 3 reading, 4 quiz |
| `resource_type_label` | Human readable resource type name |
| `hardness` | IRT style hardness parameter |
| `pool` | `recommendation` or `held_out`; the held-out pool serves the diagnostic pretest and posttest, split at 4 to 1 within each knowledge point |

### courses.csv

| Field | Description |
| --- | --- |
| `course_id` | C1 to C4 |
| `title` | English course title |
| `learners_enrolled` | Number of enrolled learners |
| `total_records` | Total interaction records in the course |
| `median_items_per_learner` | Median distinct assessment items per enrolled learner |
| `correct_response_rate` | Proportion of correct responses |

### annotator_ratings.csv

Six ECTE faculty members (four women and two men, mean 12.4 years of
teaching experience) rated 412 candidate prerequisite pairs independently.
For each pair, every annotator recorded existence, direction and a 1 to 3
strength rating (1 advisable, 2 expected, 3 strictly required). The 153
edges of `prerequisites.csv` are the pairs that the panel retained after
discussion, and the normalised strength w equals the mean of the non-zero
strength ratings divided by 3.

| Field | Description |
| --- | --- |
| `pair_id` | Candidate pair identifier 1 to 412 |
| `kp_a`, `kp_b` | Two knowledge points involved in the candidate pair |
| `accepted` | 1 if the panel accepted the pair as an edge, 0 otherwise |
| `annotator_id` | A1 to A6 |
| `annotator_gender` | F or M |
| `annotator_years_experience` | Teaching experience in years |
| `exists` | 1 if the annotator marked a prerequisite relation, 0 otherwise |
| `direction` | `KP_a->KP_b`, `KP_b->KP_a` or `none` if exists = 0 |
| `strength` | 1, 2 or 3 when exists = 1; 0 otherwise |

## Data governance

* Learner, record and session identifiers are salted SHA-256 hashes,
  truncated to 16 hexadecimal characters.
* Every timestamp carries a per-learner random offset of ±45 days.
* Names, emails and contact information have been removed.
* Deidentification took place under approval by the Ethics Committee for
  Research at Mohammed V University in Rabat.
* Response time is winsorised to [3, 900] seconds and study duration to
  [10, 3600] seconds.

## Citation

If you use the dataset, cite the accompanying paper on deep Q-network
adaptive tutoring for early childhood teacher education (details in the
top-level project README).
